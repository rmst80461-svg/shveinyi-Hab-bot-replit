
# Create handlers directory and files

handlers_commands = '''"""
Обработчики команд (/start, /help, /services, /contact).
"""

import logging
from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ParseMode

from keyboards import get_main_menu, get_services_keyboard
from utils import config

logger = logging.getLogger(__name__)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик команды /start.
    Приветствует пользователя и показывает главное меню.
    """
    user = update.effective_user
    logger.info(f"Новый пользователь: {user.id} (@{user.username})")
    
    # Добавление пользователя в базу данных
    await context.bot.db.add_user(
        user_id=user.id,
        username=user.username or "Unknown",
        first_name=user.first_name or "User"
    )
    
    # Приветственное сообщение
    await update.message.reply_text(
        config.WELCOME_MESSAGE,
        reply_markup=get_main_menu(),
        parse_mode=ParseMode.HTML
    )


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Обработчик команды /help."""
    help_text = """<b>📖 Справка по боту</b>

<b>Основные команды:</b>
/start - Главное меню
/services - Каталог услуг
/order - Оформить заказ
/status - Проверить статус заказа
/contact - Контакты мастерской
/help - Эта справка

<b>Как использовать:</b>
1️⃣ Выберите интересующую вас команду
2️⃣ Ответьте на вопросы бота
3️⃣ Загрузите фото изделия
4️⃣ Получите уведомление о готовности

<b>Вопросы:</b>
Просто напишите мне любой вопрос о ремонте одежды, и я помогу! 💬"""
    
    await update.message.reply_text(
        help_text,
        parse_mode=ParseMode.HTML
    )


async def services(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Обработчик команды /services."""
    services_text = """<b>🧵 УСЛУГИ МАСТЕРСКОЙ</b>

<b>👖 Подшить брюки/юбку</b>
  • Простая подгибка: 300₽
  • Со сбережением фабричного шва: 500₽

<b>🔌 Заменить молнию</b>
  • Простая замена: 400₽
  • Метал/дизайнерская молния: 800₽

<b>📏 Ушить/расширить одежду</b>
  • Ушить по боку: 500-700₽
  • Расширить: 600-1000₽

<b>🔘 Пришить пуговицы</b>
  • Одна пуговица: 100₽
  • Несколько: 200₽

<b>🩹 Заплатка/зашить дыру</b>
  • Скрытый шов: 300₽
  • Видимая заплатка: 400₽
  • Большая дыра: 600₽

<b>👗 Индивидуальный пошив</b>
  • Расценки по договоренности

<i>Все цены указаны примерно и могут измениться в зависимости от сложности работы.</i>"""
    
    await update.message.reply_text(
        services_text,
        parse_mode=ParseMode.HTML
    )


async def contact(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Обработчик команды /contact."""
    contact_text = """<b>📍 КОНТАКТЫ МАСТЕРСКОЙ</b>

<b>Адрес:</b>
ул. Примерная, д. 42, офис 5
Москва, 101000

<b>Телефон:</b>
+7 (495) 123-45-67

<b>График работы:</b>
Пн-Пт: 10:00 - 19:00
Сб: 11:00 - 17:00
Вс: выходной

<b>Услуги доставки:</b>
✅ Бесплатный самовывоз
✅ Доставка курьером (150₽)
✅ Почта России

Вопросы? Пишите прямо сюда! 💬"""
    
    await update.message.reply_text(
        contact_text,
        parse_mode=ParseMode.HTML
    )
'''

handlers_messages = '''"""
Обработчик обычных текстовых сообщений.
Включает поиск в базе знаний и интеграцию с GigaChat.
"""

import logging
from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ParseMode

from utils.knowledge_base import KnowledgeBase
from utils.gigachat_api import ask_gigachat
from utils.anti_spam import check_spam, is_workshop_related
from utils import config

logger = logging.getLogger(__name__)

kb = KnowledgeBase()


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Основной обработчик текстовых сообщений.
    Следует логике: спам-проверка → KB → GigaChat.
    """
    user = update.effective_user
    message_text = update.message.text
    
    logger.info(f"Сообщение от {user.id}: {message_text[:50]}")
    
    # === ПРОВЕРКА СПАМА ===
    spam_check = await check_spam(user.id, message_text)
    
    if spam_check['is_blocked']:
        await update.message.reply_text(config.BLOCK_MESSAGE)
        return
    
    if spam_check['is_spam']:
        await update.message.reply_text(config.WARNING_MESSAGE)
        if spam_check['warning_added']:
            await update.message.reply_text(
                f"⚠️ Предупреждение ({spam_check['warnings']}/{config.WARNING_LIMIT})"
            )
        return
    
    if spam_check['rate_limited']:
        await update.message.reply_text(config.RATE_LIMIT_MESSAGE)
        return
    
    # === ПОИСК В БАЗЕ ЗНАНИЙ ===
    kb_answer = kb.search(message_text)
    
    if kb_answer:
        logger.info(f"Найден ответ в KB для пользователя {user.id}")
        await update.message.reply_text(
            f"✂️ {kb_answer}\\n\\n<i>Если вам нужна дополнительная информация, пишите!</i>",
            parse_mode=ParseMode.HTML
        )
        return
    
    # === ПРОВЕРКА РЕЛЕВАНТНОСТИ ===
    if not await is_workshop_related(message_text):
        await update.message.reply_text(config.WARNING_MESSAGE)
        return
    
    # === ОТПРАВКА В GIGACHAT ===
    await update.message.chat.send_action("typing")
    
    try:
        response = await ask_gigachat(message_text)
        await update.message.reply_text(
            f"💬 {response}\\n\\n<i>Если нужна дополнительная информация, обращайтесь!</i>",
            parse_mode=ParseMode.HTML
        )
    except Exception as e:
        logger.error(f"Ошибка GigaChat: {e}")
        await update.message.reply_text(
            "Извините, произошла ошибка при обработке вашего вопроса. "
            "Пожалуйста, попробуйте позже или свяжитесь с администратором. 📞"
        )
'''

handlers_orders = '''"""
Обработчик flow оформления заказов (conversation handler).
"""

import logging
import uuid
from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes, ConversationHandler
from telegram.constants import ParseMode

from keyboards import get_services_keyboard, get_cancel_button
from utils import config

logger = logging.getLogger(__name__)

# Константы состояний conversation
SELECT_SERVICE = 1
SERVICE_PHOTO = 2
USER_NAME = 3
USER_PHONE = 4


async def order_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Начало оформления заказа."""
    await update.message.reply_text(
        "<b>➕ Оформление нового заказа</b>\\n\\n"
        "Выберите нужную услугу:",
        reply_markup=get_services_keyboard(),
        parse_mode=ParseMode.HTML
    )
    return SELECT_SERVICE


async def select_service(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Выбор услуги."""
    service_map = {
        "hem": "Подшить брюки/юбку",
        "zipper": "Заменить молнию",
        "alter": "Ушить/расширить",
        "buttons": "Пришить пуговицы",
        "patch": "Заплатка/заштопать",
        "custom": "Индивидуальный пошив",
    }
    
    # Сохранение выбора
    context.user_data['service'] = update.message.text
    
    await update.message.reply_text(
        "Отлично! ✂️\\n\\n"
        f"<b>Услуга:</b> {context.user_data['service']}\\n\\n"
        "Пожалуйста, пришлите фото изделия 📸",
        parse_mode=ParseMode.HTML,
        reply_markup=get_cancel_button()
    )
    return SERVICE_PHOTO


async def receive_photo(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Получение фото изделия."""
    photo = update.message.photo[-1]  # Берем максимальное разрешение
    context.user_data['photo_id'] = photo.file_id
    
    await update.message.reply_text(
        "Спасибо за фото! 😊\\n\\n"
        "Как к вам обращаться? Укажите имя:",
        reply_markup=get_cancel_button()
    )
    return USER_NAME


async def receive_name(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Получение имени пользователя."""
    context.user_data['name'] = update.message.text
    
    await update.message.reply_text(
        f"Спасибо, {context.user_data['name']}! ✅\\n\\n"
        "И ваш номер телефона для связи? 📱\\n"
        "<i>Например: +7 (495) 123-45-67 или 8 (495) 123-45-67</i>",
        parse_mode=ParseMode.HTML,
        reply_markup=get_cancel_button()
    )
    return USER_PHONE


async def receive_phone(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Получение телефона и завершение заказа."""
    phone = update.message.text
    context.user_data['phone'] = phone
    
    # Генерируем ID заказа
    order_id = str(uuid.uuid4())[:8].upper()
    
    # Сохраняем заказ в БД
    await context.bot.db.create_order(
        user_id=update.effective_user.id,
        service_type=context.user_data['service'],
        description=f"Фото: {context.user_data['photo_id']}",
        photo_file_id=context.user_data['photo_id'],
        estimated_price=500,  # Примерная цена
    )
    
    # Уведомление пользователю
    confirmation = (
        f"✅ <b>Заказ принят!</b>\\n\\n"
        f"<b>№ заказа:</b> {order_id}\\n"
        f"<b>Услуга:</b> {context.user_data['service']}\\n"
        f"<b>Ваше имя:</b> {context.user_data['name']}\\n"
        f"<b>Телефон:</b> {phone}\\n"
        f"<b>Примерная стоимость:</b> 500₽\\n\\n"
        f"Спасибо за обращение! Мы свяжемся с вами в ближайшее время. 💬"
    )
    
    await update.message.reply_text(
        confirmation,
        parse_mode=ParseMode.HTML
    )
    
    # Уведомление администратору
    admin_notification = (
        f"<b>🔔 Новый заказ!</b>\\n\\n"
        f"<b>ID заказа:</b> {order_id}\\n"
        f"<b>Пользователь:</b> {update.effective_user.first_name} (@{update.effective_user.username})\\n"
        f"<b>Услуга:</b> {context.user_data['service']}\\n"
        f"<b>Имя:</b> {context.user_data['name']}\\n"
        f"<b>Телефон:</b> {phone}\\n"
        f"<b>Время:</b> {update.message.date}"
    )
    
    for admin_id in config.ADMIN_IDS:
        try:
            await context.bot.send_message(
                chat_id=admin_id,
                text=admin_notification,
                parse_mode=ParseMode.HTML
            )
        except Exception as e:
            logger.error(f"Ошибка отправки админ-уведомления: {e}")
    
    return ConversationHandler.END


async def check_status(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Проверка статуса заказа."""
    await update.message.reply_text(
        "Введите номер вашего заказа (8 символов):"
    )


async def cancel_order(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Отмена заказа."""
    await update.message.reply_text(
        "❌ Заказ отменен.\\n\\n"
        "Если передумали - просто выполните /order заново! 😊"
    )
    return ConversationHandler.END
'''

handlers_admin = '''"""
Обработчики администраторских команд.
"""

import logging
from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ParseMode
from utils import config

logger = logging.getLogger(__name__)


def require_admin(func):
    """Декоратор для проверки прав администратора."""
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if update.effective_user.id not in config.ADMIN_IDS:
            await update.message.reply_text("❌ У вас нет доступа к этой команде.")
            return
        return await func(update, context)
    return wrapper


@require_admin
async def admin_stats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Показать статистику бота."""
    stats = await context.bot.db.get_statistics()
    
    stats_text = f"""<b>📊 СТАТИСТИКА БОТА</b>

<b>Пользователи:</b>
  • Всего: {stats.get('total_users', 0)}
  • За последний день: {stats.get('users_today', 0)}

<b>Заказы:</b>
  • Всего: {stats.get('total_orders', 0)}
  • Новых: {stats.get('orders_new', 0)}
  • В работе: {stats.get('orders_in_progress', 0)}
  • Готовых: {stats.get('orders_ready', 0)}

<b>Спам:</b>
  • Заблокировано: {stats.get('blocked_users', 0)}
  • Предупреждений: {stats.get('total_warnings', 0)}"""
    
    await update.message.reply_text(stats_text, parse_mode=ParseMode.HTML)


@require_admin
async def admin_orders(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Показать список заказов."""
    orders = await context.bot.db.get_recent_orders(limit=10)
    
    if not orders:
        await update.message.reply_text("Нет заказов.")
        return
    
    orders_text = "<b>📋 ПОСЛЕДНИЕ ЗАКАЗЫ</b>\\n\\n"
    
    for order in orders:
        orders_text += (
            f"<b>ID:</b> {order['order_id']}\\n"
            f"<b>Услуга:</b> {order['service_type']}\\n"
            f"<b>Статус:</b> {order['status']}\\n"
            f"<b>Цена:</b> {order['estimated_price']}₽\\n"
            f"<b>Дата:</b> {order['created_at']}\\n\\n"
        )
    
    await update.message.reply_text(orders_text, parse_mode=ParseMode.HTML)


@require_admin
async def admin_spam_log(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Показать лог спама."""
    spam_entries = await context.bot.db.get_spam_log(limit=20)
    
    if not spam_entries:
        await update.message.reply_text("Нет записей спама.")
        return
    
    spam_text = "<b>🚫 ЛОГ СПАМА</b>\\n\\n"
    
    for entry in spam_entries:
        spam_text += (
            f"<b>Тип:</b> {entry['spam_type']}\\n"
            f"<b>Дата:</b> {entry['timestamp']}\\n\\n"
        )
    
    await update.message.reply_text(spam_text, parse_mode=ParseMode.HTML)
'''

# Create handlers directory
os.makedirs('handlers', exist_ok=True)

# Write handler files
with open('handlers/__init__.py', 'w') as f:
    f.write('')

with open('handlers/commands.py', 'w', encoding='utf-8') as f:
    f.write(handlers_commands)

with open('handlers/messages.py', 'w', encoding='utf-8') as f:
    f.write(handlers_messages)

with open('handlers/orders.py', 'w', encoding='utf-8') as f:
    f.write(handlers_orders)

with open('handlers/admin.py', 'w', encoding='utf-8') as f:
    f.write(handlers_admin)

print("✅ Созданы handlers: commands.py, messages.py, orders.py, admin.py")
