
# Create README and additional documentation

readme_content = '''# 🧵 Telegram-бот швейной мастерской

Профессиональный Telegram-бот для швейной мастерской по ремонту одежды с интеграцией с GigaChat, системой защиты от спама и расширенной базой знаний.

## 🌟 Основные возможности

### 📋 Управление заказами
- ✅ Оформление новых заказов через бота
- 📸 Загрузка фото изделия
- 🔍 Проверка статуса заказа
- 💬 Уведомления о готовности
- 📊 Админ-панель для управления заказами

### 🧠 Интеллектуальные функции
- 📚 Локальная база знаний в текстовых файлах
- 🤖 Интеграция с GigaChat API
- 🔄 Автоматический выбор источника ответа (KB или AI)
- 💡 Понимание контекста вопросов

### 🛡️ Защита от спама (4 слоя)
- ⏱️ **Layer 1**: Rate limiting (5 сообщений/минуту, 20/час)
- 🚫 **Layer 2**: Фильтр по ключевым словам (blacklist/whitelist)
- 👁️ **Layer 3**: Анализ поведения (повторения, ссылки)
- 🤖 **Layer 4**: AI-проверка релевантности

### 👨‍💼 Админ-функции
- 📊 Статистика использования бота
- 📋 Управление заказами
- 🚫 Лог спама и заблокированные пользователи
- 📢 Рассылка сообщений пользователям

### 🎨 Удобный интерфейс
- ✨ Friendly Russian interface
- 📱 Inline и reply клавиатуры
- 🎯 Интуитивное меню
- 💬 Естественный диалог

## 📦 Структура проекта

```
bot/
├── main.py                 # Точка входа приложения
├── config.py              # Конфигурация и настройки
├── keyboards.py           # Клавиатуры и кнопки
│
├── handlers/              # Обработчики команд и сообщений
│   ├── commands.py        # /start, /services, /contact, /help
│   ├── messages.py        # Обработка текстовых сообщений
│   ├── orders.py          # Conversation handler для заказов
│   └── admin.py           # Администраторские команды
│
├── utils/                 # Утилиты и модули
│   ├── database.py        # Работа с SQLite
│   ├── knowledge_base.py  # Поиск в KB
│   ├── gigachat_api.py    # Интеграция с GigaChat
│   └── anti_spam.py       # Система защиты от спама
│
├── data/
│   ├── workshop.db        # SQLite база данных
│   └── knowledge_base/    # Текстовые файлы KB
│       ├── services.txt
│       ├── faq.txt
│       ├── materials.txt
│       ├── delivery.txt
│       ├── contacts.txt
│       └── policies.txt
│
├── requirements.txt       # Зависимости проекта
├── .env.template         # Шаблон переменных окружения
└── README.md            # Этот файл
```

## 🚀 Быстрый старт

### Предварительные требования
- Python 3.10+
- pip (менеджер пакетов Python)
- Токен Telegram-бота (от @BotFather)
- GigaChat API credentials (от Sber Cloud)

### 1️⃣ Установка и настройка

```bash
# Клонирование репозитория
git clone <repo-url>
cd bot

# Создание виртуального окружения
python -m venv venv

# Активация виртуального окружения
# На Windows:
venv\\Scripts\\activate
# На Linux/macOS:
source venv/bin/activate

# Установка зависимостей
pip install -r requirements.txt
```

### 2️⃣ Конфигурация

Создайте файл `.env` на основе `.env.template`:

```bash
cp .env.template .env
```

Отредактируйте `.env` и добавьте ваши данные:

```env
# Токен от @BotFather в Telegram
BOT_TOKEN=your_token_here_123456789

# GigaChat credentials от Sber Cloud
GIGACHAT_CREDENTIALS=your_credentials_here

# ID администраторов (через запятую)
ADMIN_IDS=123456789,987654321
```

### 3️⃣ Запуск бота

```bash
python main.py
```

Вы должны увидеть:
```
Запуск Telegram-бота швейной мастерской...
✅ База данных инициализирована
✅ Загружено 50+ записей в KB
Бот готов к работе!
```

## 📚 База знаний

База знаний организована в текстовые файлы в папке `data/knowledge_base/`:

### Формат записей

```
ВОПРОС: Сколько стоит укоротить джинсы?
ОТВЕТ: Стоимость укорочения джинс составляет 300-500 рублей в зависимости от сложности...
KEYWORDS: укоротить, джинсы, подшить, цена
---
```

### Файлы KB

| Файл | Содержание |
|------|-----------|
| `services.txt` | Услуги, цены, описания |
| `faq.txt` | Часто задаваемые вопросы |
| `materials.txt` | Типы материалов, особенности работы |
| `delivery.txt` | Доставка, самовывоз, условия |
| `contacts.txt` | Адрес, телефон, график работы |
| `policies.txt` | Гарантия, оплата, скидки |

### Добавление новых вопросов

Просто отредактируйте нужный `.txt` файл:

```
ВОПРОС: Ваш вопрос здесь?
ОТВЕТ: Ваш полный ответ с деталями...
KEYWORDS: ключевое_слово1, ключевое_слово2, ключевое_слово3
---
```

## 🤖 Команды бота

### Для пользователей

| Команда | Описание |
|---------|----------|
| `/start` | Главное меню и приветствие |
| `/services` | Каталог услуг и цены |
| `/order` | Оформить новый заказ |
| `/status` | Проверить статус заказа |
| `/contact` | Контакты мастерской |
| `/help` | Справка по боту |

### Для администраторов

| Команда | Описание |
|---------|----------|
| `/admin_stats` | Статистика использования бота |
| `/admin_orders` | Список последних заказов |
| `/admin_spam` | Лог спама и блокировок |

## 🛡️ Система защиты от спама

### Layer 1: Rate Limiting
- Максимум 5 сообщений в минуту
- Максимум 20 сообщений в час
- Временное молчание (5 минут) при превышении
- Отслеживание в SQLite базе

### Layer 2: Topic Relevance Filter

**Blacklist ключевые слова** (вызывают предупреждение):
- Криптовалюты: крипто, биткойн, форекс
- Взрослый контент: xxx, 18+
- Спам: заработок, инвестиции, бесплатно, кредит

**Whitelist ключевые слова** (всегда разрешены):
- Ремонт: подшить, ушить, молния, пуговица
- Ткани: джинса, кожа, шелк, трикотаж
- Заказы: заказ, цена, сроки, забрать

### Layer 3: Behavior Analysis
Отслеживание подозрительных паттернов:
- Одно сообщение повторяется 3+ раза → автоблок
- 3+ внешние ссылки → фильтр
- Сообщения на иностранных языках → проверка

### Layer 4: AI-Powered Relevance
Проверка релевантности вопроса мастерской перед отправкой в GigaChat

## 📊 База данных

### Таблица users
```sql
CREATE TABLE users (
    user_id INTEGER PRIMARY KEY,
    username TEXT,
    first_name TEXT,
    join_date DATETIME,
    message_count INTEGER,
    last_message_time DATETIME,
    is_blocked BOOLEAN,
    warning_count INTEGER
);
```

### Таблица orders
```sql
CREATE TABLE orders (
    order_id TEXT PRIMARY KEY,
    user_id INTEGER,
    service_type TEXT,
    description TEXT,
    photo_file_id TEXT,
    estimated_price INTEGER,
    status TEXT,
    created_at DATETIME,
    updated_at DATETIME
);
```

## 🔌 Интеграция с GigaChat

### Системный промпт

```python
SYSTEM_PROMPT = """Ты - дружелюбный помощник швейной мастерской по ремонту одежды.
Отвечай вежливо, по существу, простым языком.
Специализация: ремонт одежды, подгонка, замена фурнитуры, ушивка/расширение.
Если вопрос не связан с ремонтом одежды - вежливо объясни, что ты помогаешь только по вопросам мастерской.
Всегда предлагай оформить заказ через команду /order."""
```

### Использование

Вопросы автоматически отправляются в GigaChat если:
1. Не найдены в локальной KB
2. Прошли проверку релевантности
3. Не являются спамом

## 📱 Примеры использования

### Пример 1: Обычный вопрос

```
Пользователь: Сколько стоит укоротить джинсы?

Бот (из KB): ✂️ Стоимость укорочения зависит от сложности работы:
• Простая подгибка: 300₽
• Со сбережением фабричного шва: 500₽
Срок выполнения: 2-3 рабочих дня.
```

### Пример 2: Оформление заказа

```
Пользователь: /order

Бот: ➕ Оформление нового заказа
     Выберите нужную услугу:
     [👖 Подшить брюки/юбку]
     [🔌 Заменить молнию]
     ...
```

### Пример 3: Защита от спама

```
Пользователь: Привет! Заработай крипто!

Бот: Извините, но этот вопрос не связан с услугами нашей мастерской. 🤔
     Я помогаю только с вопросами о ремонте одежды.
     Если у вас есть вещь, которую нужно починить - буду рад помочь! ✂️

⚠️ Предупреждение (1/3)
```

## 🔧 Разработка и тестирование

### Тестирование anti-spam системы

```python
from utils.anti_spam import check_spam

# Тест rate limiting
result = await check_spam(user_id=123, message="test")
assert not result['rate_limited']

# Тест blacklist
result = await check_spam(user_id=123, message="заработай крипто")
assert result['is_spam']

# Тест whitelist
result = await check_spam(user_id=123, message="сколько стоит подшить джинсы")
assert not result['is_spam']
```

### Тестирование KB

```python
from utils.knowledge_base import KnowledgeBase

kb = KnowledgeBase()
answer = kb.search("сколько стоит укоротить брюки")
assert answer is not None
print(answer)
```

## 📈 Мониторинг и логирование

Все события логируются в консоль:
- Новые пользователи
- Поступившие заказы
- Спам-события
- Ошибки и исключения

Логи также сохраняются в базе данных для аналитики.

## 🚀 Развертывание

### На Replit

1. Создайте новый проект Replit Python
2. Клонируйте этот репозиторий
3. Установите зависимости: `pip install -r requirements.txt`
4. Создайте `.env` файл с вашими credentials
5. Запустите `python main.py`
6. Используйте Replit UPtime для keep-alive

### На VPS (Ubuntu/Debian)

```bash
# Установка Python
sudo apt update
sudo apt install python3.10 python3.10-venv

# Клонирование и настройка
git clone <repo-url>
cd bot
python3.10 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Запуск с systemd
sudo nano /etc/systemd/system/bot.service
```

Содержание `bot.service`:
```ini
[Unit]
Description=Telegram Workshop Bot
After=network.target

[Service]
Type=simple
User=bot
WorkingDirectory=/path/to/bot
ExecStart=/path/to/bot/venv/bin/python main.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

Затем:
```bash
sudo systemctl enable bot
sudo systemctl start bot
```

## 🔐 Безопасность

### Лучшие практики

- ✅ Никогда не логируйте чувствительные данные (телефоны, номера заказов)
- ✅ Хешируйте user IDs в спам-логах
- ✅ Используйте HTTPS для всех API запросов
- ✅ Валидируйте все пользовательские вводы
- ✅ Не используйте eval() или exec()
- ✅ Регулярно обновляйте зависимости

### Environment Variables

```env
# Никогда не коммитьте .env в Git!
# Добавьте в .gitignore:
.env
*.db
__pycache__/
venv/
```

## 📞 Поддержка и контакты

**Основной телефон:** +7 (495) 123-45-67
**Email:** info@masterskaya-remonta.ru
**Адрес:** ул. Примерная, д. 42, офис 5, Москва

## 📝 Лицензия

Этот проект распространяется под лицензией MIT.

## 🙏 Благодарности

- python-telegram-bot - асинхронная библиотека для работы с Telegram API
- GigaChat - AI от Sberbank
- Сообщество Python разработчиков

## 📋 Чек-лист развертывания

- [ ] Python 3.10+ установлен
- [ ] Получен токен от @BotFather
- [ ] Получены GigaChat credentials
- [ ] Создан файл .env с данными
- [ ] Установлены зависимости (`pip install -r requirements.txt`)
- [ ] База знаний загружена и проверена
- [ ] Администраторские IDs добавлены в config
- [ ] Тестирование локально прошло успешно
- [ ] Бот запущен на сервере
- [ ] Мониторинг настроен
- [ ] Резервная копия базы данных сделана

---

**Версия:** 1.0.0
**Последнее обновление:** 2024
**Статус:** Production Ready ✅

Спасибо за использование нашего бота! 🎉
'''

# Create .gitignore
gitignore_content = '''# Environment
.env
.env.local
.env.*.local

# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
env/
venv/
ENV/
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
*.egg-info/
.installed.cfg
*.egg

# IDE
.vscode/
.idea/
*.swp
*.swo
*~
.project
.pydevproject

# OS
.DS_Store
Thumbs.db
*.log

# Database
*.db
*.sqlite
*.sqlite3

# Pytest
.pytest_cache/
.coverage
htmlcov/

# Temp files
*.tmp
*.temp
/tmp/
/temp/

# Telegram bot related
bot_state.json
conversation_state.json
'''

# Create requirements-dev.txt for development
requirements_dev = '''python-telegram-bot==20.7
gigachat==0.2.1
python-dotenv==1.0.0
aiosqlite==0.19.0
httpx==0.24.1
pydantic==2.5.0

# Development
pytest==7.4.0
pytest-asyncio==0.21.0
black==23.10.0
flake8==6.1.0
isort==5.12.0
mypy==1.6.1
'''

# Create test file
test_content = '''"""
Примеры тестов для anti-spam системы и KB.
"""

import asyncio
import pytest
from utils.anti_spam import check_spam, check_content_spam
from utils.knowledge_base import KnowledgeBase


class TestAntiSpam:
    """Тесты системы защиты от спама."""
    
    @pytest.mark.asyncio
    async def test_rate_limit_passed(self):
        """Тест: нормальное сообщение проходит."""
        result = await check_spam(user_id=999, message="Сколько стоит подшить?")
        assert not result['rate_limited']
        assert not result['is_spam']
    
    @pytest.mark.asyncio
    async def test_blacklist_detection(self):
        """Тест: blacklist слова детектируются."""
        result = check_content_spam(user_id=999, message="заработай крипто")
        assert result['is_spam']
    
    @pytest.mark.asyncio
    async def test_multiple_warnings(self):
        """Тест: после 3 предупреждений пользователь блокируется."""
        user_id = 888
        for i in range(3):
            await check_spam(user_id=user_id, message="спам спам спам" * 3)
        
        result = await check_spam(user_id=user_id, message="тест")
        assert result['is_blocked']


class TestKnowledgeBase:
    """Тесты базы знаний."""
    
    def test_kb_loading(self):
        """Тест: KB загружается успешно."""
        kb = KnowledgeBase()
        assert len(kb.entries) > 0
    
    def test_kb_search_services(self):
        """Тест: поиск по услугам."""
        kb = KnowledgeBase()
        answer = kb.search("сколько стоит укоротить брюки?")
        assert answer is not None
        assert "300" in answer or "рублей" in answer.lower()
    
    def test_kb_search_no_result(self):
        """Тест: KB возвращает None для непонятного запроса."""
        kb = KnowledgeBase()
        answer = kb.search("xyzabc123xyz")
        assert answer is None


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
'''

# Write files
with open('README.md', 'w', encoding='utf-8') as f:
    f.write(readme_content)

with open('.gitignore', 'w', encoding='utf-8') as f:
    f.write(gitignore_content)

with open('requirements-dev.txt', 'w', encoding='utf-8') as f:
    f.write(requirements_dev)

with open('tests.py', 'w', encoding='utf-8') as f:
    f.write(test_content)

print("✅ Созданы документация и тесты:")
print("   - README.md (подробная документация)")
print("   - .gitignore (исключения для Git)")
print("   - requirements-dev.txt (для разработки)")
print("   - tests.py (примеры тестов)")
