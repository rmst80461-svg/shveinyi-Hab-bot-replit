
# Create utils directory and files

utils_database = '''"""
Модуль работы с базой данных SQLite.
"""

import logging
import sqlite3
from datetime import datetime, timedelta
from typing import Dict, List, Optional

from utils import config

logger = logging.getLogger(__name__)


class Database:
    """Управление базой данных."""
    
    def __init__(self, db_path: str = config.DB_PATH):
        """Инициализация подключения к БД."""
        self.db_path = db_path
        self.conn = None
    
    async def init(self) -> None:
        """Инициализация таблиц базы данных."""
        try:
            self.conn = sqlite3.connect(self.db_path)
            self.conn.row_factory = sqlite3.Row
            cursor = self.conn.cursor()
            
            # Таблица пользователей
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    user_id INTEGER PRIMARY KEY,
                    username TEXT,
                    first_name TEXT,
                    join_date DATETIME DEFAULT CURRENT_TIMESTAMP,
                    message_count INTEGER DEFAULT 0,
                    last_message_time DATETIME,
                    is_blocked BOOLEAN DEFAULT 0,
                    warning_count INTEGER DEFAULT 0
                )
            """)
            
            # Таблица заказов
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS orders (
                    order_id TEXT PRIMARY KEY,
                    user_id INTEGER,
                    service_type TEXT,
                    description TEXT,
                    photo_file_id TEXT,
                    estimated_price INTEGER,
                    status TEXT DEFAULT 'new',
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY(user_id) REFERENCES users(user_id)
                )
            """)
            
            # Таблица логирования спама
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS spam_log (
                    log_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    message_text TEXT,
                    spam_type TEXT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY(user_id) REFERENCES users(user_id)
                )
            """)
            
            # Таблица rate limits
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS rate_limits (
                    user_id INTEGER PRIMARY KEY,
                    message_count INTEGER DEFAULT 0,
                    last_reset_time DATETIME DEFAULT CURRENT_TIMESTAMP,
                    muted_until DATETIME,
                    FOREIGN KEY(user_id) REFERENCES users(user_id)
                )
            """)
            
            # Таблица взаимодействий
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS interactions (
                    interaction_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    question TEXT,
                    answer_source TEXT,
                    response TEXT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY(user_id) REFERENCES users(user_id)
                )
            """)
            
            self.conn.commit()
            logger.info("✅ База данных инициализирована")
            
        except Exception as e:
            logger.error(f"❌ Ошибка инициализации БД: {e}")
            raise
    
    async def add_user(self, user_id: int, username: str, first_name: str) -> None:
        """Добавить нового пользователя."""
        try:
            cursor = self.conn.cursor()
            cursor.execute("""
                INSERT OR IGNORE INTO users (user_id, username, first_name)
                VALUES (?, ?, ?)
            """, (user_id, username, first_name))
            
            # Инициализация rate limit
            cursor.execute("""
                INSERT OR IGNORE INTO rate_limits (user_id)
                VALUES (?)
            """, (user_id,))
            
            self.conn.commit()
        except Exception as e:
            logger.error(f"Ошибка добавления пользователя: {e}")
    
    async def create_order(self, user_id: int, service_type: str, 
                          description: str, photo_file_id: str, 
                          estimated_price: int) -> str:
        """Создать новый заказ."""
        import uuid
        order_id = str(uuid.uuid4())[:8].upper()
        
        try:
            cursor = self.conn.cursor()
            cursor.execute("""
                INSERT INTO orders 
                (order_id, user_id, service_type, description, photo_file_id, estimated_price)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (order_id, user_id, service_type, description, photo_file_id, estimated_price))
            
            self.conn.commit()
            return order_id
        except Exception as e:
            logger.error(f"Ошибка создания заказа: {e}")
            return None
    
    async def get_user_stats(self, user_id: int) -> Dict:
        """Получить статистику пользователя."""
        try:
            cursor = self.conn.cursor()
            cursor.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
            user = cursor.fetchone()
            return dict(user) if user else {}
        except Exception as e:
            logger.error(f"Ошибка получения статистики: {e}")
            return {}
    
    async def get_statistics(self) -> Dict:
        """Получить общую статистику бота."""
        try:
            cursor = self.conn.cursor()
            
            cursor.execute("SELECT COUNT(*) as count FROM users")
            total_users = cursor.fetchone()['count']
            
            today = datetime.now().date()
            cursor.execute(
                "SELECT COUNT(*) as count FROM users WHERE DATE(join_date) = ?",
                (today,)
            )
            users_today = cursor.fetchone()['count']
            
            cursor.execute("SELECT COUNT(*) as count FROM orders")
            total_orders = cursor.fetchone()['count']
            
            cursor.execute("SELECT COUNT(*) as count FROM orders WHERE status = 'new'")
            orders_new = cursor.fetchone()['count']
            
            cursor.execute("SELECT COUNT(*) as count FROM users WHERE is_blocked = 1")
            blocked_users = cursor.fetchone()['count']
            
            return {
                'total_users': total_users,
                'users_today': users_today,
                'total_orders': total_orders,
                'orders_new': orders_new,
                'orders_in_progress': 0,
                'orders_ready': 0,
                'blocked_users': blocked_users,
                'total_warnings': 0,
            }
        except Exception as e:
            logger.error(f"Ошибка получения статистики: {e}")
            return {}
    
    async def get_recent_orders(self, limit: int = 10) -> List[Dict]:
        """Получить недавние заказы."""
        try:
            cursor = self.conn.cursor()
            cursor.execute("""
                SELECT * FROM orders ORDER BY created_at DESC LIMIT ?
            """, (limit,))
            
            return [dict(row) for row in cursor.fetchall()]
        except Exception as e:
            logger.error(f"Ошибка получения заказов: {e}")
            return []
    
    async def get_spam_log(self, limit: int = 20) -> List[Dict]:
        """Получить лог спама."""
        try:
            cursor = self.conn.cursor()
            cursor.execute("""
                SELECT * FROM spam_log ORDER BY timestamp DESC LIMIT ?
            """, (limit,))
            
            return [dict(row) for row in cursor.fetchall()]
        except Exception as e:
            logger.error(f"Ошибка получения спам-лога: {e}")
            return []
    
    async def add_spam_log(self, user_id: int, message_text: str, spam_type: str) -> None:
        """Логирование спама."""
        try:
            cursor = self.conn.cursor()
            cursor.execute("""
                INSERT INTO spam_log (user_id, message_text, spam_type)
                VALUES (?, ?, ?)
            """, (user_id, message_text[:500], spam_type))
            
            self.conn.commit()
        except Exception as e:
            logger.error(f"Ошибка логирования спама: {e}")
    
    def close(self) -> None:
        """Закрыть подключение."""
        if self.conn:
            self.conn.close()
'''

utils_knowledge_base = '''"""
Модуль поиска в базе знаний.
"""

import os
import logging
import re
from typing import Optional
from utils import config

logger = logging.getLogger(__name__)


class KnowledgeBase:
    """Поиск информации в базе знаний."""
    
    def __init__(self, kb_path: str = config.KB_PATH):
        """Инициализация базы знаний."""
        self.kb_path = kb_path
        self.entries = []
        self._load_knowledge_base()
    
    def _load_knowledge_base(self) -> None:
        """Загрузка всех файлов KB в память."""
        if not os.path.exists(self.kb_path):
            logger.warning(f"Папка KB не найдена: {self.kb_path}")
            return
        
        for filename in os.listdir(self.kb_path):
            if filename.endswith('.txt'):
                filepath = os.path.join(self.kb_path, filename)
                self._load_kb_file(filepath)
        
        logger.info(f"✅ Загружено {len(self.entries)} записей в KB")
    
    def _load_kb_file(self, filepath: str) -> None:
        """Загрузить один файл KB."""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Парсим формат: ВОПРОС: ... ОТВЕТ: ... KEYWORDS: ...
            entries = content.split('---')
            
            for entry in entries:
                entry = entry.strip()
                if not entry:
                    continue
                
                lines = entry.split('\\n')
                question = ""
                answer = ""
                keywords = ""
                
                for line in lines:
                    if line.startswith('ВОПРОС:'):
                        question = line.replace('ВОПРОС:', '').strip()
                    elif line.startswith('ОТВЕТ:'):
                        answer = line.replace('ОТВЕТ:', '').strip()
                    elif line.startswith('KEYWORDS:'):
                        keywords = line.replace('KEYWORDS:', '').strip()
                
                if question and answer:
                    self.entries.append({
                        'question': question,
                        'answer': answer,
                        'keywords': keywords.lower().split(','),
                        'file': filename
                    })
        
        except Exception as e:
            logger.error(f"Ошибка загрузки KB файла {filepath}: {e}")
    
    def search(self, query: str) -> Optional[str]:
        """
        Поиск ответа в базе знаний.
        
        Args:
            query: Вопрос пользователя
            
        Returns:
            Ответ или None
        """
        query_lower = query.lower()
        query_words = set(query_lower.split())
        
        best_match = None
        best_score = 0
        
        for entry in self.entries:
            # Поиск по ключевым словам
            keywords = entry['keywords']
            score = 0
            
            for keyword in keywords:
                keyword = keyword.strip()
                if keyword in query_lower:
                    score += 2
                for word in query_words:
                    if keyword.startswith(word) or word in keyword:
                        score += 1
            
            # Поиск в самом вопросе
            question_words = set(entry['question'].lower().split())
            common_words = query_words.intersection(question_words)
            score += len(common_words)
            
            if score > best_score:
                best_score = score
                best_match = entry
        
        if best_score > 2:  # Порог совпадения
            return best_match['answer']
        
        return None
'''

utils_gigachat = '''"""
Модуль интеграции с GigaChat API.
"""

import logging
import os
from typing import Optional
from utils import config

logger = logging.getLogger(__name__)

# Используем mock для демонстрации, так как требуется реальный GigaChat API
SYSTEM_PROMPT = """Ты - дружелюбный помощник швейной мастерской по ремонту одежды.
Отвечай вежливо, по существу, простым языком.
Специализация: ремонт одежды, подгонка, замена фурнитуры, ушивка/расширение.
Если вопрос не связан с ремонтом одежды - вежливо объясни, что ты помогаешь только по вопросам мастерской.
Всегда предлагай оформить заказ через команду /order."""


async def ask_gigachat(question: str, user_context: str = "") -> str:
    """
    Отправить вопрос в GigaChat API.
    
    Args:
        question: Вопрос пользователя
        user_context: Контекст (имя, история, и т.д.)
        
    Returns:
        Ответ от GigaChat
    """
    try:
        # Проверка credentials
        creds = os.getenv('GIGACHAT_CREDENTIALS')
        if not creds:
            logger.warning("GigaChat credentials не найдены")
            return get_fallback_response(question)
        
        # Реальная интеграция с GigaChat
        # Здесь должен быть код с использованием gigachat library
        # from gigachat import GigaChat
        # with GigaChat(credentials=creds, verify_ssl_certs=False) as giga:
        #     messages = [
        #         {"role": "system", "content": SYSTEM_PROMPT},
        #         {"role": "user", "content": question}
        #     ]
        #     response = giga.chat(messages)
        #     return response.choices[0].message.content
        
        # Для демонстрации возвращаем заглушку
        return get_fallback_response(question)
        
    except Exception as e:
        logger.error(f"Ошибка GigaChat: {e}")
        return get_fallback_response(question)


def get_fallback_response(question: str) -> str:
    """Fallback ответ, когда GigaChat недоступен."""
    return (
        "Спасибо за вопрос! К сожалению, я не смог обработать его прямо сейчас. "
        "Пожалуйста, позвоните нам напрямую: +7 (495) 123-45-67 или используйте /contact. "
        "Я здесь, чтобы помочь! 😊"
    )
'''

utils_anti_spam = '''"""
Модуль защиты от спама и проверки релевантности.
"""

import logging
import re
from datetime import datetime, timedelta
from typing import Dict, Optional
from utils import config

logger = logging.getLogger(__name__)

# Глобальные хранилища (в продакшене использовать DB)
user_message_count = {}
user_mute_until = {}
user_warnings = {}
recent_messages = {}  # Для проверки повторов


async def check_spam(user_id: int, message_text: str) -> Dict:
    """
    Комплексная проверка спама.
    
    Args:
        user_id: ID пользователя
        message_text: Текст сообщения
        
    Returns:
        Dict с результатами проверки
    """
    
    # === LAYER 1: ПРОВЕРКА БЛОКИРОВКИ ===
    if user_warnings.get(user_id, 0) >= config.WARNING_LIMIT:
        return {'is_blocked': True, 'is_spam': False, 'rate_limited': False}
    
    # === LAYER 2: ПРОВЕРКА MUTE ===
    now = datetime.now()
    if user_id in user_mute_until and user_mute_until[user_id] > now:
        return {'is_blocked': False, 'is_spam': False, 'rate_limited': True}
    
    # === LAYER 3: RATE LIMIT ===
    current_minute = now.minute
    hour_key = f"{now.hour}"
    
    if user_id not in user_message_count:
        user_message_count[user_id] = {'minute': 0, 'hour': 0, 'last_minute': current_minute}
    
    # Сброс счетчика минут, если изменилась минута
    if user_message_count[user_id]['last_minute'] != current_minute:
        user_message_count[user_id]['minute'] = 0
        user_message_count[user_id]['last_minute'] = current_minute
    
    user_message_count[user_id]['minute'] += 1
    user_message_count[user_id]['hour'] += 1
    
    # Проверка лимитов
    if user_message_count[user_id]['minute'] > config.RATE_LIMIT_MESSAGES:
        user_mute_until[user_id] = now + timedelta(seconds=config.MUTE_DURATION)
        return {'is_blocked': False, 'is_spam': False, 'rate_limited': True}
    
    if user_message_count[user_id]['hour'] > config.RATE_LIMIT_HOURLY:
        return {'is_blocked': False, 'is_spam': False, 'rate_limited': True}
    
    # === LAYER 4: ПРОВЕРКА КОНТЕНТА ===
    spam_result = check_content_spam(user_id, message_text)
    
    if spam_result['is_spam']:
        user_warnings[user_id] = user_warnings.get(user_id, 0) + 1
        return {
            'is_blocked': False,
            'is_spam': True,
            'rate_limited': False,
            'warning_added': True,
            'warnings': user_warnings[user_id]
        }
    
    return {'is_blocked': False, 'is_spam': False, 'rate_limited': False}


def check_content_spam(user_id: int, message_text: str) -> Dict:
    """Проверка содержимого сообщения на спам."""
    
    message_lower = message_text.lower()
    
    # Проверка blacklist ключевых слов
    for keyword in config.BLACKLIST_KEYWORDS:
        if keyword in message_lower:
            logger.info(f"Спам: обнаружено blacklist слово '{keyword}' от {user_id}")
            return {'is_spam': True, 'reason': 'blacklist_keyword'}
    
    # Проверка повторов
    if user_id in recent_messages:
        if recent_messages[user_id] == message_text:
            recent_messages[user_id]['count'] = recent_messages[user_id].get('count', 0) + 1
            if recent_messages[user_id]['count'] >= 3:
                logger.info(f"Спам: повторное сообщение от {user_id}")
                return {'is_spam': True, 'reason': 'repeated_message'}
    else:
        recent_messages[user_id] = message_text
    
    # Проверка ссылок
    link_count = len(re.findall(r'http[s]?://\\S+', message_text))
    if link_count >= 3:
        logger.info(f"Спам: слишком много ссылок от {user_id}")
        return {'is_spam': True, 'reason': 'too_many_links'}
    
    return {'is_spam': False}


async def is_workshop_related(message_text: str) -> bool:
    """
    Проверка релевантности вопроса мастерской.
    
    Args:
        message_text: Текст сообщения
        
    Returns:
        True если релевантно, False иначе
    """
    message_lower = message_text.lower()
    
    # Проверка whitelist
    for keyword in config.WHITELIST_KEYWORDS:
        if keyword in message_lower:
            return True
    
    # Проверка общих признаков вопроса о мастерской
    workshop_keywords = ['мастер', 'ремонт', 'швей', 'одежд', 'чинить', 'пошив']
    
    for keyword in workshop_keywords:
        if keyword in message_lower:
            return True
    
    # Если сообщение короткое и общее - отклонить
    if len(message_text.split()) < 2:
        return False
    
    # Вопросительные слова о мастерской
    if any(q in message_lower for q in ['сколько', 'как', 'где', 'когда', 'чем']):
        return True
    
    # Все остальное проверяем как потенциально релевантное
    # (полная проверка через GigaChat должна быть в production)
    return True
'''

# Create utils directory
os.makedirs('utils', exist_ok=True)

# Write utility files
with open('utils/__init__.py', 'w') as f:
    f.write('')

with open('utils/database.py', 'w', encoding='utf-8') as f:
    f.write(utils_database)

with open('utils/knowledge_base.py', 'w', encoding='utf-8') as f:
    f.write(utils_knowledge_base)

with open('utils/gigachat_api.py', 'w', encoding='utf-8') as f:
    f.write(utils_gigachat)

with open('utils/anti_spam.py', 'w', encoding='utf-8') as f:
    f.write(utils_anti_spam)

print("✅ Созданы utils модули: database.py, knowledge_base.py, gigachat_api.py, anti_spam.py")
