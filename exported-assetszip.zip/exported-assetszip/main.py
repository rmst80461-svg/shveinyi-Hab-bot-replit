#!/usr/bin/env python3
"""
Основной модуль Telegram-бота швейной мастерской.
Точка входа приложения с инициализацией всех компонентов.
"""

import logging
import os
import asyncio
from dotenv import load_dotenv
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    filters,
    ConversationHandler,
)
from telegram import BotCommand

try:
    import nest_asyncio
    nest_asyncio.apply()
except ImportError:
    pass

from handlers import commands, messages, orders, admin, callbacks
from utils.database import Database

# Загрузка переменных окружения
load_dotenv()

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)


async def initialize_app() -> Application:
    """
    Инициализация приложения Telegram Bot.

    Returns:
        Application: Полностью настроенное приложение
    """
    # Получение токена из переменных окружения
    token = os.getenv('BOT_TOKEN')
    if not token:
        raise ValueError("BOT_TOKEN не найден в .env файле")

    # Инициализация базы данных
    db = Database()
    await db.init()
    
    # Создание приложения
    app = Application.builder().token(token).build()
    
    # Используем post_init для установки БД и меню команд
    async def post_init(app):
        app.bot_data['db'] = db
        
        # Установка меню команд
        commands = [
            BotCommand("start", "🏠 Главное меню"),
            BotCommand("order", "➕ Оформить заказ"),
            BotCommand("services", "📋 Услуги и цены"),
            BotCommand("contact", "📞 Контакты"),
            BotCommand("help", "❓ Справка"),
        ]
        await app.bot.set_my_commands(commands)
        logger.info("✅ Меню команд установлено")
    
    app.post_init = post_init

    # Регистрация обработчиков команд
    app.add_handler(CommandHandler('start', commands.start))
    app.add_handler(CommandHandler('help', commands.help_command))
    app.add_handler(CommandHandler('services', commands.services))
    app.add_handler(CommandHandler('contact', commands.contact))

    # Обработчик заказов (conversation handler)
    order_handler = ConversationHandler(
        entry_points=[CommandHandler('order', orders.order_start)],
        states={
            orders.SELECT_SERVICE: [MessageHandler(filters.TEXT, orders.select_service)],
            orders.SERVICE_PHOTO: [
                MessageHandler(filters.PHOTO, orders.receive_photo),
                CallbackQueryHandler(orders.skip_photo_callback, pattern="skip_photo"),
                CommandHandler('cancel', orders.cancel_order)
            ],
            orders.USER_NAME: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, orders.receive_name),
                CommandHandler('cancel', orders.cancel_order)
            ],
            orders.USER_PHONE: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, orders.receive_phone),
                CommandHandler('cancel', orders.cancel_order)
            ],
        },
        fallbacks=[CommandHandler('cancel', orders.cancel_order)],
    )

    app.add_handler(order_handler)

    # Обработчик проверки статуса заказа
    app.add_handler(CommandHandler('status', orders.check_status))

    # Админские команды
    app.add_handler(CommandHandler('admin_stats', admin.admin_stats))
    app.add_handler(CommandHandler('admin_orders', admin.admin_orders))
    app.add_handler(CommandHandler('admin_spam', admin.admin_spam_log))

    # Обработчик нажатий на inline кнопки (callback)
    app.add_handler(CallbackQueryHandler(callbacks.button_callback))

    # Обработчик обычных сообщений (должен быть последним)
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, messages.handle_message))

    return app


async def main() -> None:
    """Основная функция запуска бота."""
    logger.info("Запуск Telegram-бота швейной мастерской...")

    app = await initialize_app()

    # Запуск с длинным опросом
    logger.info("Бот готов к работе!")
    await app.run_polling(allowed_updates=['message', 'callback_query'], drop_pending_updates=True)


if __name__ == '__main__':
    asyncio.run(main())
