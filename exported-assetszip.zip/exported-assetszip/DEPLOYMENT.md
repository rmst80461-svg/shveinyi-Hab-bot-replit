# 🚀 ГАЙД ПО РАЗВЕРТЫВАНИЮ БОТА

## Вариант 1: Локальное развертывание (для тестирования)

### Шаг 1: Установка зависимостей

```bash
# Создание виртуального окружения
python -m venv venv

# Активация (Windows)
venv\Scripts\activate

# Активация (Linux/macOS)
source venv/bin/activate

# Установка пакетов
pip install -r requirements.txt
```

### Шаг 2: Настройка .env

```bash
cp .env.template .env
```

Отредактируйте `.env` и добавьте:
- BOT_TOKEN (от @BotFather)
- GIGACHAT_CREDENTIALS (от Sber Cloud)
- ADMIN_IDS (ваш ID)

### Шаг 3: Запуск

```bash
python main.py
```

Бот будет запущен и готов к использованию!

---

## Вариант 2: Развертывание на Replit

### Шаг 1: Создание проекта

1. Перейдите на https://replit.com
2. Нажмите "Create" → выберите Python
3. Клонируйте репозиторий или загрузите файлы

### Шаг 2: Установка зависимостей

В терминале Replit:
```bash
pip install -r requirements.txt
```

### Шаг 3: Добавление secrets

1. Нажмите на замок 🔐 слева
2. Добавьте переменные:
   - BOT_TOKEN
   - GIGACHAT_CREDENTIALS
   - ADMIN_IDS

### Шаг 4: Keep-Alive (для постоянной работы)

Добавьте в `.replit`:
```
run = "python main.py"
```

Или используйте UptimeRobot для ping бота каждые 5 минут:
```
https://replit-bot.replit.dev/ping
```

---

## Вариант 3: VPS/Linux Server (Production)

### Шаг 1: Подготовка сервера

```bash
# Обновление системы
sudo apt update && sudo apt upgrade -y

# Установка Python 3.10+
sudo apt install python3.10 python3.10-venv python3-pip -y

# Установка git
sudo apt install git -y
```

### Шаг 2: Клонирование проекта

```bash
# Создание папки для бота
sudo mkdir -p /opt/telegram-bot
cd /opt/telegram-bot

# Клонирование репозитория
sudo git clone <repository-url> .

# Смена владельца
sudo chown -R $USER:$USER /opt/telegram-bot
```

### Шаг 3: Настройка окружения

```bash
# Создание виртуального окружения
python3.10 -m venv venv
source venv/bin/activate

# Установка зависимостей
pip install -r requirements.txt

# Копирование шаблона .env
cp .env.template .env

# Редактирование .env
nano .env
```

### Шаг 4: Создание systemd сервиса

Создайте файл `/etc/systemd/system/telegram-bot.service`:

```bash
sudo nano /etc/systemd/system/telegram-bot.service
```

Добавьте содержимое:

```ini
[Unit]
Description=Telegram Workshop Repair Bot
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/telegram-bot
Environment="PATH=/opt/telegram-bot/venv/bin"
ExecStart=/opt/telegram-bot/venv/bin/python /opt/telegram-bot/main.py
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
```

### Шаг 5: Запуск сервиса

```bash
# Перезагрузка systemd
sudo systemctl daemon-reload

# Включение сервиса на автозапуск
sudo systemctl enable telegram-bot

# Запуск сервиса
sudo systemctl start telegram-bot

# Проверка статуса
sudo systemctl status telegram-bot

# Просмотр логов
sudo journalctl -u telegram-bot -f
```

### Шаг 6: Firewall (если нужно)

```bash
# Открытие порта 8080 (если используется webhook)
sudo ufw allow 8080/tcp

# Или разрешить все для бота
sudo ufw allow from any to any port 8080
```

### Шаг 7: SSL сертификат (для webhook режима)

```bash
# Установка certbot
sudo apt install certbot -y

# Получение сертификата
sudo certbot certonly --standalone -d your-domain.com
```

---

## Вариант 4: Docker

### Dockerfile

```dockerfile
FROM python:3.10-slim

WORKDIR /app

# Установка зависимостей системы
RUN apt-get update && apt-get install -y \
    gcc \
    && rm -rf /var/lib/apt/lists/*

# Копирование файлов
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

# Создание директорий для данных
RUN mkdir -p data/knowledge_base

# Запуск бота
CMD ["python", "main.py"]
```

### Docker Compose

```yaml
version: '3.8'

services:
  bot:
    build: .
    environment:
      - BOT_TOKEN=${BOT_TOKEN}
      - GIGACHAT_CREDENTIALS=${GIGACHAT_CREDENTIALS}
      - ADMIN_IDS=${ADMIN_IDS}
    volumes:
      - ./data:/app/data
    restart: always
```

### Запуск Docker

```bash
# Сборка образа
docker build -t telegram-bot .

# Запуск контейнера
docker run -d \
  -e BOT_TOKEN="your_token" \
  -e GIGACHAT_CREDENTIALS="your_credentials" \
  -e ADMIN_IDS="123456789" \
  -v /opt/telegram-bot/data:/app/data \
  --restart always \
  --name workshop-bot \
  telegram-bot
```

---

## Мониторинг и Логирование

### Просмотр логов на сервере

```bash
# Для systemd сервиса
sudo journalctl -u telegram-bot -f --lines 100

# Для Docker контейнера
docker logs -f workshop-bot

# Сохранение логов в файл
sudo journalctl -u telegram-bot > /var/log/telegram-bot.log
```

### Мониторинг работоспособности

Создайте скрипт healthcheck.py:

```python
import requests
import os

BOT_TOKEN = os.getenv('BOT_TOKEN')
ADMIN_ID = os.getenv('ADMIN_IDS').split(',')[0]

try:
    # Попытка отправить тестовое сообщение
    requests.post(
        f'https://api.telegram.org/bot{BOT_TOKEN}/sendMessage',
        json={'chat_id': ADMIN_ID, 'text': '✅ Бот активен'}
    )
    print("Bot is healthy")
except Exception as e:
    print(f"Bot is down: {e}")
    # Отправка алерта (опционально)
```

### Автоматическая перезагрузка при сбое

Уже настроена в systemd: `Restart=always`

---

## Обновление бота

### Безопасное обновление

```bash
# Остановка бота
sudo systemctl stop telegram-bot

# Обновление кода
cd /opt/telegram-bot
git pull origin main

# Установка новых зависимостей (если есть)
source venv/bin/activate
pip install -r requirements.txt

# Запуск бота
sudo systemctl start telegram-bot

# Проверка
sudo systemctl status telegram-bot
```

---

## Резервное копирование

### Автоматическое backup

```bash
#!/bin/bash
# backup.sh

DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/backups/telegram-bot"
mkdir -p $BACKUP_DIR

# Копирование базы данных
cp /opt/telegram-bot/data/workshop.db $BACKUP_DIR/workshop_${DATE}.db

# Копирование KB
cp -r /opt/telegram-bot/data/knowledge_base $BACKUP_DIR/kb_${DATE}

# Удаление старых backup'ов (старше 30 дней)
find $BACKUP_DIR -name "workshop_*.db" -mtime +30 -delete

echo "Backup completed: $DATE"
```

Добавьте в crontab (запуск каждый день в 3:00 ночи):

```bash
crontab -e

# Добавьте строку:
0 3 * * * /opt/telegram-bot/backup.sh
```

---

## Troubleshooting

### Проблема: "BotCommandNotFound"

**Решение:** Убедитесь, что BOT_TOKEN правильный

```bash
# Проверка токена
curl -s https://api.telegram.org/bot<YOUR_TOKEN>/getMe
```

### Проблема: "Connection refused"

**Решение:** Проверьте интернет соединение и firewall

```bash
# Проверка подключения
ping google.com
sudo ufw status
```

### Проблема: "Database is locked"

**Решение:** Закройте все подключения к БД

```bash
# Перезагрузите бота
sudo systemctl restart telegram-bot

# Удалите lock файл (если есть)
rm -f /opt/telegram-bot/data/.db-lock
```

### Проблема: "GigaChat API error"

**Решение:** Проверьте credentials и баланс

```bash
# Проверка credentials в .env
cat /opt/telegram-bot/.env | grep GIGACHAT
```

---

## Развертывание на Replit (Подробно)

1. Создайте новый проект: https://replit.com/new/python
2. Загрузите файлы или нажмите "Git"
3. Добавьте secrets (🔐):
   ```
   BOT_TOKEN=...
   GIGACHAT_CREDENTIALS=...
   ADMIN_IDS=...
   ```
4. В консоли:
   ```bash
   pip install -r requirements.txt
   python main.py
   ```
5. Закрепите приложение (для постоянной работы)
6. Используйте UptimeRobot для ping каждые 5 минут

---

## Чек-лист перед production

- [ ] BOT_TOKEN получен и работает
- [ ] GigaChat credentials получены
- [ ] ADMIN_IDS добавлены
- [ ] База знаний заполнена
- [ ] Тестирование на локальной машине прошло
- [ ] Ошибки обработаны gracefully
- [ ] Логирование настроено
- [ ] Backup策略 продумана
- [ ] Firewall открыт
- [ ] SSL сертификат получен (если нужен webhook)
- [ ] Мониторинг настроен
- [ ] На случай аварии есть manual recovery план

---

Готово! 🎉 Ваш бот должен быть полностью функциональным!
