#!/bin/bash
# Скрипт первоначальной настройки бота

echo "🚀 Инициализация Telegram-бота швейной мастерской"
echo ""

# Проверка Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 не установлен"
    exit 1
fi

echo "✅ Python установлен: $(python3 --version)"

# Создание виртуального окружения
echo ""
echo "📦 Создание виртуального окружения..."
python3 -m venv venv

# Активация
source venv/bin/activate

# Установка зависимостей
echo "📥 Установка зависимостей..."
pip install -r requirements.txt

# Создание .env
echo ""
echo "⚙️  Настройка переменных окружения"
if [ ! -f .env ]; then
    cp .env.template .env
    echo "✅ Файл .env создан. Пожалуйста, отредактируйте его:"
    echo "   nano .env"
    echo ""
    echo "Необходимо добавить:"
    echo "  - BOT_TOKEN (от @BotFather)"
    echo "  - GIGACHAT_CREDENTIALS (от Sber Cloud)"
    echo "  - ADMIN_IDS (ваш ID в Telegram)"
else
    echo "✅ .env файл уже существует"
fi

# Инициализация БД
echo ""
echo "🗄️  Инициализация базы данных..."
python3 init_db.py

echo ""
echo "✨ Готово! Для запуска бота выполните:"
echo "   python3 main.py"
