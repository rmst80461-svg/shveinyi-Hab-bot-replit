"""
Примеры тестов для anti-spam системы и KB.
"""

import asyncio
import pytest
from utils.anti_spam import check_spam, check_content_spam
from utils.knowledge_base import KnowledgeBase


class TestAntiSpam:
    """Тесты системы защиты от спама."""

    @pytest.mark.asyncio
    async def test_rate_limit_passed(self):
        """Тест: нормальное сообщение проходит."""
        result = await check_spam(user_id=999, message="Сколько стоит подшить?")
        assert not result['rate_limited']
        assert not result['is_spam']

    @pytest.mark.asyncio
    async def test_blacklist_detection(self):
        """Тест: blacklist слова детектируются."""
        result = check_content_spam(user_id=999, message="заработай крипто")
        assert result['is_spam']

    @pytest.mark.asyncio
    async def test_multiple_warnings(self):
        """Тест: после 3 предупреждений пользователь блокируется."""
        user_id = 888
        for i in range(3):
            await check_spam(user_id=user_id, message="спам спам спам" * 3)

        result = await check_spam(user_id=user_id, message="тест")
        assert result['is_blocked']


class TestKnowledgeBase:
    """Тесты базы знаний."""

    def test_kb_loading(self):
        """Тест: KB загружается успешно."""
        kb = KnowledgeBase()
        assert len(kb.entries) > 0

    def test_kb_search_services(self):
        """Тест: поиск по услугам."""
        kb = KnowledgeBase()
        answer = kb.search("сколько стоит укоротить брюки?")
        assert answer is not None
        assert "300" in answer or "рублей" in answer.lower()

    def test_kb_search_no_result(self):
        """Тест: KB возвращает None для непонятного запроса."""
        kb = KnowledgeBase()
        answer = kb.search("xyzabc123xyz")
        assert answer is None


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
