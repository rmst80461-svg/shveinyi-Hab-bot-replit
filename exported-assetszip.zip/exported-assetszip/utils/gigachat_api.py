"""
Модуль интеграции с GigaChat API от Сбера.
"""

import logging
import os
from typing import Optional
from utils import config

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """Ты - дружелюбный помощник швейной мастерской по ремонту одежды.
Отвечай вежливо, по существу, простым языком.
Специализация: ремонт одежды, подгонка, замена фурнитуры, ушивка/расширение.
Если вопрос не связан с ремонтом одежды - вежливо объясни, что ты помогаешь только по вопросам мастерской.
Всегда предлагай оформить заказ через команду /order."""


async def ask_gigachat(question: str, user_context: str = "") -> str:
    """
    Отправить вопрос в GigaChat API.

    Args:
        question: Вопрос пользователя
        user_context: Контекст (имя, история, и т.д.)

    Returns:
        Ответ от GigaChat
    """
    try:
        # Проверка credentials
        creds = os.getenv('GIGACHAT_CREDENTIALS')
        if not creds:
            logger.warning("⚠️ GigaChat credentials не найдены. Используется fallback.")
            return get_fallback_response(question)

        # Интеграция с GigaChat
        try:
            from gigachat import GigaChat
            
            # Инициализация GigaChat с учетными данными
            client = GigaChat(
                credentials=creds,
                verify_ssl_certs=False,
                scope="https://e.sbercloud.ru/api/v1/giga-chat-plus"
            )
            
            messages = [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": question}
            ]
            
            response = client.chat(messages)
            answer = response.choices[0].message.content
            
            logger.info(f"✅ GigaChat ответил: {answer[:100]}...")
            return answer
            
        except ImportError:
            logger.warning("GigaChat библиотека не установлена")
            return get_fallback_response(question)
        except Exception as e:
            logger.error(f"❌ Ошибка GigaChat API: {e}")
            return get_fallback_response(question)

    except Exception as e:
        logger.error(f"❌ Ошибка в ask_gigachat: {e}")
        return get_fallback_response(question)


def get_fallback_response(question: str) -> str:
    """Fallback ответ, когда GigaChat недоступен."""
    return (
        "Спасибо за вопрос! 😊\n\n"
        "Я обрабатываю вашу информацию. "
        "Свяжитесь с нами для получения подробной информации:\n\n"
        "Используйте /contact для получения полной контактной информации!"
    )
