"""
Модуль защиты от спама и проверки релевантности.
"""

import logging
import re
from datetime import datetime, timedelta
from typing import Dict, Optional
from utils import config

logger = logging.getLogger(__name__)

# Глобальные хранилища (в продакшене использовать DB)
user_message_count = {}
user_mute_until = {}
user_warnings = {}
recent_messages = {}  # Для проверки повторов


async def check_spam(user_id: int, message_text: str) -> Dict:
    """
    Комплексная проверка спама.

    Args:
        user_id: ID пользователя
        message_text: Текст сообщения

    Returns:
        Dict с результатами проверки
    """

    # === LAYER 1: ПРОВЕРКА БЛОКИРОВКИ ===
    if user_warnings.get(user_id, 0) >= config.WARNING_LIMIT:
        return {'is_blocked': True, 'is_spam': False, 'rate_limited': False}

    # === LAYER 2: ПРОВЕРКА MUTE ===
    now = datetime.now()
    if user_id in user_mute_until and user_mute_until[user_id] > now:
        return {'is_blocked': False, 'is_spam': False, 'rate_limited': True}

    # === LAYER 3: RATE LIMIT ===
    current_minute = now.minute
    hour_key = f"{now.hour}"

    if user_id not in user_message_count:
        user_message_count[user_id] = {'minute': 0, 'hour': 0, 'last_minute': current_minute}

    # Сброс счетчика минут, если изменилась минута
    if user_message_count[user_id]['last_minute'] != current_minute:
        user_message_count[user_id]['minute'] = 0
        user_message_count[user_id]['last_minute'] = current_minute

    user_message_count[user_id]['minute'] += 1
    user_message_count[user_id]['hour'] += 1

    # Проверка лимитов
    if user_message_count[user_id]['minute'] > config.RATE_LIMIT_MESSAGES:
        user_mute_until[user_id] = now + timedelta(seconds=config.MUTE_DURATION)
        return {'is_blocked': False, 'is_spam': False, 'rate_limited': True}

    if user_message_count[user_id]['hour'] > config.RATE_LIMIT_HOURLY:
        return {'is_blocked': False, 'is_spam': False, 'rate_limited': True}

    # === LAYER 4: ПРОВЕРКА КОНТЕНТА ===
    spam_result = check_content_spam(user_id, message_text)

    if spam_result['is_spam']:
        user_warnings[user_id] = user_warnings.get(user_id, 0) + 1
        return {
            'is_blocked': False,
            'is_spam': True,
            'rate_limited': False,
            'warning_added': True,
            'warnings': user_warnings[user_id]
        }

    return {'is_blocked': False, 'is_spam': False, 'rate_limited': False}


def check_content_spam(user_id: int, message_text: str) -> Dict:
    """Проверка содержимого сообщения на спам."""

    message_lower = message_text.lower()

    # Проверка blacklist ключевых слов
    for keyword in config.BLACKLIST_KEYWORDS:
        if keyword in message_lower:
            logger.info(f"Спам: обнаружено blacklist слово '{keyword}' от {user_id}")
            return {'is_spam': True, 'reason': 'blacklist_keyword'}

    # Проверка повторов
    if user_id in recent_messages:
        if recent_messages[user_id] == message_text:
            recent_messages[user_id]['count'] = recent_messages[user_id].get('count', 0) + 1
            if recent_messages[user_id]['count'] >= 3:
                logger.info(f"Спам: повторное сообщение от {user_id}")
                return {'is_spam': True, 'reason': 'repeated_message'}
    else:
        recent_messages[user_id] = message_text

    # Проверка ссылок
    link_count = len(re.findall(r'http[s]?://\S+', message_text))
    if link_count >= 3:
        logger.info(f"Спам: слишком много ссылок от {user_id}")
        return {'is_spam': True, 'reason': 'too_many_links'}

    return {'is_spam': False}


async def is_workshop_related(message_text: str) -> bool:
    """
    Проверка релевантности вопроса мастерской.

    Args:
        message_text: Текст сообщения

    Returns:
        True если релевантно, False иначе
    """
    message_lower = message_text.lower()

    # Проверка whitelist
    for keyword in config.WHITELIST_KEYWORDS:
        if keyword in message_lower:
            return True

    # Проверка общих признаков вопроса о мастерской
    workshop_keywords = ['мастер', 'ремонт', 'швей', 'одежд', 'чинить', 'пошив']

    for keyword in workshop_keywords:
        if keyword in message_lower:
            return True

    # Если сообщение короткое и общее - отклонить
    if len(message_text.split()) < 2:
        return False

    # Вопросительные слова о мастерской
    if any(q in message_lower for q in ['сколько', 'как', 'где', 'когда', 'чем']):
        return True

    # Все остальное проверяем как потенциально релевантное
    # (полная проверка через GigaChat должна быть в production)
    return True
