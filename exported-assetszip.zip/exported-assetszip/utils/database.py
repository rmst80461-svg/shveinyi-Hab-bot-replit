"""
Модуль работы с базой данных SQLite (асинхронный).
"""

import logging
import uuid
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import aiosqlite

from utils import config

logger = logging.getLogger(__name__)


class Database:
    """Управление базой данных с асинхронными операциями."""

    def __init__(self, db_path: str = config.DB_PATH):
        """Инициализация подключения к БД."""
        self.db_path = db_path
        self.conn = None

    async def init(self) -> None:
        """Инициализация таблиц базы данных."""
        try:
            self.conn = await aiosqlite.connect(self.db_path)
            self.conn.row_factory = aiosqlite.Row

            # Таблица пользователей
            await self.conn.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    user_id INTEGER PRIMARY KEY,
                    username TEXT,
                    first_name TEXT,
                    join_date DATETIME DEFAULT CURRENT_TIMESTAMP,
                    message_count INTEGER DEFAULT 0,
                    last_message_time DATETIME,
                    is_blocked BOOLEAN DEFAULT 0,
                    warning_count INTEGER DEFAULT 0
                )
            """)

            # Таблица заказов
            await self.conn.execute("""
                CREATE TABLE IF NOT EXISTS orders (
                    order_id TEXT PRIMARY KEY,
                    user_id INTEGER,
                    service_type TEXT,
                    description TEXT,
                    photo_file_id TEXT,
                    estimated_price INTEGER,
                    status TEXT DEFAULT 'new',
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY(user_id) REFERENCES users(user_id)
                )
            """)

            # Таблица логирования спама
            await self.conn.execute("""
                CREATE TABLE IF NOT EXISTS spam_log (
                    log_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    message_text TEXT,
                    spam_type TEXT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY(user_id) REFERENCES users(user_id)
                )
            """)

            # Таблица rate limits
            await self.conn.execute("""
                CREATE TABLE IF NOT EXISTS rate_limits (
                    user_id INTEGER PRIMARY KEY,
                    message_count INTEGER DEFAULT 0,
                    last_reset_time DATETIME DEFAULT CURRENT_TIMESTAMP,
                    muted_until DATETIME,
                    FOREIGN KEY(user_id) REFERENCES users(user_id)
                )
            """)

            # Таблица взаимодействий
            await self.conn.execute("""
                CREATE TABLE IF NOT EXISTS interactions (
                    interaction_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    question TEXT,
                    answer_source TEXT,
                    response TEXT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY(user_id) REFERENCES users(user_id)
                )
            """)

            await self.conn.commit()
            logger.info("✅ База данных инициализирована (aiosqlite)")

        except Exception as e:
            logger.error(f"❌ Ошибка инициализации БД: {e}")
            raise

    async def add_user(self, user_id: int, username: str, first_name: str) -> None:
        """Добавить нового пользователя."""
        try:
            await self.conn.execute("""
                INSERT OR IGNORE INTO users (user_id, username, first_name)
                VALUES (?, ?, ?)
            """, (user_id, username, first_name))

            # Инициализация rate limit
            await self.conn.execute("""
                INSERT OR IGNORE INTO rate_limits (user_id)
                VALUES (?)
            """, (user_id,))

            await self.conn.commit()
            logger.info(f"✅ Пользователь {user_id} добавлен в БД")
        except Exception as e:
            logger.error(f"Ошибка добавления пользователя: {e}")

    async def create_order(self, user_id: int, service_type: str, 
                          description: str, photo_file_id: str, 
                          estimated_price: int) -> str:
        """Создать новый заказ."""
        order_id = str(uuid.uuid4())[:8].upper()

        try:
            await self.conn.execute("""
                INSERT INTO orders 
                (order_id, user_id, service_type, description, photo_file_id, estimated_price)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (order_id, user_id, service_type, description, photo_file_id, estimated_price))

            await self.conn.commit()
            logger.info(f"✅ Заказ {order_id} создан")
            return order_id
        except Exception as e:
            logger.error(f"Ошибка создания заказа: {e}")
            return None

    async def get_user_stats(self, user_id: int) -> Dict:
        """Получить статистику пользователя."""
        try:
            async with self.conn.execute("SELECT * FROM users WHERE user_id = ?", (user_id,)) as cursor:
                user = await cursor.fetchone()
            return dict(user) if user else {}
        except Exception as e:
            logger.error(f"Ошибка получения статистики: {e}")
            return {}

    async def get_statistics(self) -> Dict:
        """Получить общую статистику бота."""
        try:
            async with self.conn.execute("SELECT COUNT(*) as count FROM users") as cursor:
                row = await cursor.fetchone()
                total_users = row[0] if row else 0

            today = datetime.now().date()
            async with self.conn.execute(
                "SELECT COUNT(*) as count FROM users WHERE DATE(join_date) = ?",
                (today,)
            ) as cursor:
                row = await cursor.fetchone()
                users_today = row[0] if row else 0

            async with self.conn.execute("SELECT COUNT(*) as count FROM orders") as cursor:
                row = await cursor.fetchone()
                total_orders = row[0] if row else 0

            async with self.conn.execute("SELECT COUNT(*) as count FROM orders WHERE status = 'new'") as cursor:
                row = await cursor.fetchone()
                orders_new = row[0] if row else 0

            async with self.conn.execute("SELECT COUNT(*) as count FROM users WHERE is_blocked = 1") as cursor:
                row = await cursor.fetchone()
                blocked_users = row[0] if row else 0

            return {
                'total_users': total_users,
                'users_today': users_today,
                'total_orders': total_orders,
                'orders_new': orders_new,
                'orders_in_progress': 0,
                'orders_ready': 0,
                'blocked_users': blocked_users,
                'total_warnings': 0,
            }
        except Exception as e:
            logger.error(f"Ошибка получения статистики: {e}")
            return {}

    async def get_recent_orders(self, limit: int = 10) -> List[Dict]:
        """Получить недавние заказы."""
        try:
            async with self.conn.execute("""
                SELECT * FROM orders ORDER BY created_at DESC LIMIT ?
            """, (limit,)) as cursor:
                rows = await cursor.fetchall()
            return [dict(row) for row in rows]
        except Exception as e:
            logger.error(f"Ошибка получения заказов: {e}")
            return []

    async def get_spam_log(self, limit: int = 20) -> List[Dict]:
        """Получить лог спама."""
        try:
            async with self.conn.execute("""
                SELECT * FROM spam_log ORDER BY timestamp DESC LIMIT ?
            """, (limit,)) as cursor:
                rows = await cursor.fetchall()
            return [dict(row) for row in rows]
        except Exception as e:
            logger.error(f"Ошибка получения спам-лога: {e}")
            return []

    async def add_spam_log(self, user_id: int, message_text: str, spam_type: str) -> None:
        """Логирование спама."""
        try:
            await self.conn.execute("""
                INSERT INTO spam_log (user_id, message_text, spam_type)
                VALUES (?, ?, ?)
            """, (user_id, message_text[:500], spam_type))

            await self.conn.commit()
        except Exception as e:
            logger.error(f"Ошибка логирования спама: {e}")

    async def close(self) -> None:
        """Закрыть подключение."""
        if self.conn:
            await self.conn.close()
