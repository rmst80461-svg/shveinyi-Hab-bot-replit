"""
Модуль поиска в базе знаний.
"""

import os
import logging
import re
from typing import Optional
from utils import config

logger = logging.getLogger(__name__)


class KnowledgeBase:
    """Поиск информации в базе знаний."""

    def __init__(self, kb_path: str = config.KB_PATH):
        """Инициализация базы знаний."""
        self.kb_path = kb_path
        self.entries = []
        self._load_knowledge_base()

    def _load_knowledge_base(self) -> None:
        """Загрузка всех файлов KB в память."""
        if not os.path.exists(self.kb_path):
            logger.warning(f"Папка KB не найдена: {self.kb_path}")
            return

        for filename in os.listdir(self.kb_path):
            if filename.endswith('.txt'):
                filepath = os.path.join(self.kb_path, filename)
                self._load_kb_file(filepath)

        logger.info(f"✅ Загружено {len(self.entries)} записей в KB")

    def _load_kb_file(self, filepath: str) -> None:
        """Загрузить один файл KB."""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()

            # Парсим формат: ВОПРОС: ... ОТВЕТ: ... KEYWORDS: ...
            entries = content.split('---')

            for entry in entries:
                entry = entry.strip()
                if not entry:
                    continue

                lines = entry.split('\n')
                question = ""
                answer = ""
                keywords = ""

                for line in lines:
                    if line.startswith('ВОПРОС:'):
                        question = line.replace('ВОПРОС:', '').strip()
                    elif line.startswith('ОТВЕТ:'):
                        answer = line.replace('ОТВЕТ:', '').strip()
                    elif line.startswith('KEYWORDS:'):
                        keywords = line.replace('KEYWORDS:', '').strip()

                if question and answer:
                    self.entries.append({
                        'question': question,
                        'answer': answer,
                        'keywords': keywords.lower().split(','),
                        'file': filename
                    })

        except Exception as e:
            logger.error(f"Ошибка загрузки KB файла {filepath}: {e}")

    def search(self, query: str) -> Optional[str]:
        """
        Поиск ответа в базе знаний.

        Args:
            query: Вопрос пользователя

        Returns:
            Ответ или None
        """
        query_lower = query.lower()
        query_words = set(query_lower.split())

        best_match = None
        best_score = 0

        for entry in self.entries:
            # Поиск по ключевым словам
            keywords = entry['keywords']
            score = 0

            for keyword in keywords:
                keyword = keyword.strip()
                if keyword in query_lower:
                    score += 2
                for word in query_words:
                    if keyword.startswith(word) or word in keyword:
                        score += 1

            # Поиск в самом вопросе
            question_words = set(entry['question'].lower().split())
            common_words = query_words.intersection(question_words)
            score += len(common_words)

            if score > best_score:
                best_score = score
                best_match = entry

        if best_score > 2:  # Порог совпадения
            return best_match['answer']

        return None
