#!/usr/bin/env python3
"""
Скрипт инициализации базы данных.
Запустите один раз перед первым запуском бота.
"""

import asyncio
import os
from dotenv import load_dotenv
from utils.database import Database
from utils.knowledge_base import KnowledgeBase

load_dotenv()


async def init_database():
    """Инициализация базы данных."""
    print("🔧 Инициализация базы данных...")

    # Создание директорий
    os.makedirs('data', exist_ok=True)
    os.makedirs('data/knowledge_base', exist_ok=True)

    # Инициализация БД
    db = Database()
    await db.init()
    print("✅ База данных инициализирована")

    # Загрузка KB
    kb = KnowledgeBase()
    print(f"✅ База знаний загружена: {len(kb.entries)} записей")

    # Добавление тестовых данных (опционально)
    print("\nДобавление тестовых пользователей...")
    await db.add_user(user_id=0, username="test_user", first_name="Test")
    print("✅ Тестовые данные добавлены")

    db.close()
    print("\n✨ Инициализация завершена!")


if __name__ == "__main__":
    asyncio.run(init_database())
