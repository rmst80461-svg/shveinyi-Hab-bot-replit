
# Create the complete project structure and generate all necessary files

import os
import json

# Define the project structure
project_files = {
    "main.py": '''#!/usr/bin/env python3
"""
Основной модуль Telegram-бота швейной мастерской.
Точка входа приложения с инициализацией всех компонентов.
"""

import logging
import os
from dotenv import load_dotenv
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    filters,
    ConversationHandler,
)

from handlers import commands, messages, orders, admin
from utils.database import Database

# Загрузка переменных окружения
load_dotenv()

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)


async def initialize_app() -> Application:
    """
    Инициализация приложения Telegram Bot.
    
    Returns:
        Application: Полностью настроенное приложение
    """
    # Получение токена из переменных окружения
    token = os.getenv('BOT_TOKEN')
    if not token:
        raise ValueError("BOT_TOKEN не найден в .env файле")
    
    # Создание приложения
    app = Application.builder().token(token).build()
    
    # Инициализация базы данных
    db = Database()
    await db.init()
    app.context_types.defaults.context_type = type('Context', (), {'db': db})()
    
    # Регистрация обработчиков команд
    app.add_handler(CommandHandler('start', commands.start))
    app.add_handler(CommandHandler('help', commands.help_command))
    app.add_handler(CommandHandler('services', commands.services))
    app.add_handler(CommandHandler('contact', commands.contact))
    
    # Обработчик заказов (conversation handler)
    order_handler = ConversationHandler(
        entry_points=[CommandHandler('order', orders.order_start)],
        states={
            orders.SELECT_SERVICE: [MessageHandler(filters.TEXT, orders.select_service)],
            orders.SERVICE_PHOTO: [
                MessageHandler(filters.PHOTO, orders.receive_photo),
                CommandHandler('cancel', orders.cancel_order)
            ],
            orders.USER_NAME: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, orders.receive_name),
                CommandHandler('cancel', orders.cancel_order)
            ],
            orders.USER_PHONE: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, orders.receive_phone),
                CommandHandler('cancel', orders.cancel_order)
            ],
        },
        fallbacks=[CommandHandler('cancel', orders.cancel_order)],
    )
    
    app.add_handler(order_handler)
    
    # Обработчик проверки статуса заказа
    app.add_handler(CommandHandler('status', orders.check_status))
    
    # Админские команды
    app.add_handler(CommandHandler('admin_stats', admin.admin_stats))
    app.add_handler(CommandHandler('admin_orders', admin.admin_orders))
    app.add_handler(CommandHandler('admin_spam', admin.admin_spam_log))
    
    # Обработчик обычных сообщений (должен быть последним)
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, messages.handle_message))
    
    return app


async def main() -> None:
    """Основная функция запуска бота."""
    logger.info("Запуск Telegram-бота швейной мастерской...")
    
    app = await initialize_app()
    
    # Запуск с длинным опросом
    logger.info("Бот готов к работе!")
    await app.run_polling(allowed_updates=['message', 'callback_query'])


if __name__ == '__main__':
    import asyncio
    asyncio.run(main())
''',
    
    "config.py": '''"""
Конфигурация приложения.
Центральное место для всех настроек и констант.
"""

import os
from typing import List

# === ТОКЕНЫ И CREDENTIALS ===
BOT_TOKEN = os.getenv('BOT_TOKEN')
GIGACHAT_CREDENTIALS = os.getenv('GIGACHAT_CREDENTIALS')
ADMIN_IDS: List[int] = list(map(int, os.getenv('ADMIN_IDS', '').split(','))) if os.getenv('ADMIN_IDS') else []

# === ANTI-SPAM НАСТРОЙКИ ===
RATE_LIMIT_MESSAGES = 5  # Сообщений в минуту
RATE_LIMIT_MINUTES = 1
RATE_LIMIT_HOURLY = 20  # Сообщений в час
RATE_LIMIT_HOUR = 60

MUTE_DURATION = 300  # 5 минут в секундах
WARNING_LIMIT = 3  # Предупреждений до блока

# === BLACKLIST КЛЮЧЕВЫХ СЛОВ ===
BLACKLIST_KEYWORDS = [
    'крипто', 'биткойн', 'форекс', 'казино', 'ставки',
    'взрослое', 'xxx', '18+',
    'заработок', 'инвестиции', 'бесплатно', 'кредит', 'займ',
    'рф', 'дом2', 'порно',
]

# === WHITELIST КЛЮЧЕВЫХ СЛОВ ===
WHITELIST_KEYWORDS = [
    'подшить', 'ушить', 'молния', 'пуговица', 'заплатка',
    'джинса', 'кожа', 'шелк', 'трикотаж', 'хлопок',
    'заказ', 'цена', 'сроки', 'забрать', 'доставка',
]

# === ПУТИ К ФАЙЛАМ ===
DB_PATH = 'data/workshop.db'
KB_PATH = 'data/knowledge_base'

# === СООБЩЕНИЯ ===
WELCOME_MESSAGE = """Добрый день! 👋 Рады видеть вас в нашей швейной мастерской!

Я здесь, чтобы помочь вам с:
🧵 Вопросами о услугах ремонта
✂️ Информацией о ценах
📸 Оформлением заказов
💬 Любыми другими вопросами о вашей одежде

Выберите команду ниже или просто напишите мне сообщение!"""

WARNING_MESSAGE = """Извините, но этот вопрос не связан с услугами нашей мастерской. 🤔
Я помогаю только с вопросами о ремонте одежды.
Если у вас есть вещь, которую нужно починить - буду рад помочь! ✂️"""

RATE_LIMIT_MESSAGE = """Пожалуйста, подождите немного перед следующим сообщением 😊
Я здесь и готов ответить, просто не торопитесь!"""

BLOCK_MESSAGE = """К сожалению, вы превысили лимит предупреждений.
Доступ к боту ограничен на время. 
Для разблокировки обратитесь к администратору мастерской."""
''',
    
    "keyboards.py": '''"""
Клавиатуры и кнопки для интерактивного взаимодействия.
"""

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton

# === INLINE КЛАВИАТУРЫ ===

def get_main_menu() -> InlineKeyboardMarkup:
    """Главное меню."""
    buttons = [
        [InlineKeyboardButton("📋 Услуги", callback_data="services")],
        [InlineKeyboardButton("➕ Новый заказ", callback_data="order")],
        [InlineKeyboardButton("🔍 Статус заказа", callback_data="status")],
        [InlineKeyboardButton("📍 Контакты", callback_data="contacts")],
    ]
    return InlineKeyboardMarkup(buttons)


def get_services_keyboard() -> InlineKeyboardMarkup:
    """Меню выбора услуг."""
    buttons = [
        [InlineKeyboardButton("👖 Подшить брюки/юбку", callback_data="service_hem")],
        [InlineKeyboardButton("🔌 Заменить молнию", callback_data="service_zipper")],
        [InlineKeyboardButton("📏 Ушить/расширить", callback_data="service_alter")],
        [InlineKeyboardButton("🔘 Пришить пуговицы", callback_data="service_buttons")],
        [InlineKeyboardButton("🩹 Заплатка/заштопать", callback_data="service_patch")],
        [InlineKeyboardButton("👗 Индивидуальный пошив", callback_data="service_custom")],
    ]
    return InlineKeyboardMarkup(buttons)


def get_confirm_order_keyboard() -> InlineKeyboardMarkup:
    """Подтверждение заказа."""
    buttons = [
        [InlineKeyboardButton("✅ Подтвердить", callback_data="confirm_order")],
        [InlineKeyboardButton("❌ Отменить", callback_data="cancel_order")],
    ]
    return InlineKeyboardMarkup(buttons)


# === REPLY КЛАВИАТУРЫ ===

def get_start_keyboard() -> ReplyKeyboardMarkup:
    """Клавиатура при старте."""
    buttons = [
        [KeyboardButton("📋 Услуги"), KeyboardButton("➕ Заказ")],
        [KeyboardButton("🔍 Статус"), KeyboardButton("📍 Контакты")],
    ]
    return ReplyKeyboardMarkup(buttons, resize_keyboard=True)


def get_cancel_button() -> ReplyKeyboardMarkup:
    """Кнопка отмены."""
    buttons = [[KeyboardButton("/cancel")]]
    return ReplyKeyboardMarkup(buttons, resize_keyboard=True)
''',
    
    "requirements.txt": '''python-telegram-bot==20.7
gigachat==0.2.1
python-dotenv==1.0.0
aiosqlite==0.19.0
httpx==0.24.1
pydantic==2.5.0
''',
    
    ".env.template": '''# Telegram Bot Token (получить от @BotFather)
BOT_TOKEN=your_token_here

# GigaChat API Credentials (от Sber Cloud)
GIGACHAT_CREDENTIALS=your_credentials_here

# ID администраторов (через запятую)
ADMIN_IDS=123456789,987654321

# Опционально
DEBUG=False
''',
}

# Create main.py
with open('main.py', 'w', encoding='utf-8') as f:
    f.write(project_files['main.py'])
    
with open('config.py', 'w', encoding='utf-8') as f:
    f.write(project_files['config.py'])
    
with open('keyboards.py', 'w', encoding='utf-8') as f:
    f.write(project_files['keyboards.py'])
    
with open('requirements.txt', 'w', encoding='utf-8') as f:
    f.write(project_files['requirements.txt'])
    
with open('.env.template', 'w', encoding='utf-8') as f:
    f.write(project_files['.env.template'])

print("✅ Основные файлы созданы: main.py, config.py, keyboards.py")
print("✅ requirements.txt и .env.template созданы")
