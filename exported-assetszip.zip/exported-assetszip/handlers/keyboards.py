"""
Клавиатуры и кнопки для интерактивного взаимодействия.
"""

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton

# === INLINE КЛАВИАТУРЫ ===

def get_main_menu() -> InlineKeyboardMarkup:
    """Главное меню."""
    buttons = [
        [InlineKeyboardButton("📋 Услуги", callback_data="services")],
        [InlineKeyboardButton("➕ Новый заказ", callback_data="order")],
        [InlineKeyboardButton("❓ FAQ", callback_data="show_faq")],
        [InlineKeyboardButton("💰 Цены", callback_data="show_prices")],
        [InlineKeyboardButton("📍 Адрес & Телефон", callback_data="show_contacts")],
        [InlineKeyboardButton("🕐 Режим работы", callback_data="show_hours")],
    ]
    return InlineKeyboardMarkup(buttons)


def get_services_keyboard() -> InlineKeyboardMarkup:
    """Меню выбора услуг."""
    buttons = [
        [InlineKeyboardButton("👖 Подшить брюки/юбку", callback_data="service_hem")],
        [InlineKeyboardButton("🔌 Заменить молнию", callback_data="service_zipper")],
        [InlineKeyboardButton("📏 Ушить/расширить", callback_data="service_alter")],
        [InlineKeyboardButton("🔘 Пришить пуговицы", callback_data="service_buttons")],
        [InlineKeyboardButton("🩹 Заплатка/заштопать", callback_data="service_patch")],
        [InlineKeyboardButton("👗 Индивидуальный пошив", callback_data="service_custom")],
    ]
    return InlineKeyboardMarkup(buttons)


def get_confirm_order_keyboard() -> InlineKeyboardMarkup:
    """Подтверждение заказа."""
    buttons = [
        [InlineKeyboardButton("✅ Подтвердить", callback_data="confirm_order")],
        [InlineKeyboardButton("❌ Отменить", callback_data="cancel_order")],
    ]
    return InlineKeyboardMarkup(buttons)


# === REPLY КЛАВИАТУРЫ ===

def get_start_keyboard() -> ReplyKeyboardMarkup:
    """Клавиатура при старте."""
    buttons = [
        [KeyboardButton("📋 Услуги"), KeyboardButton("➕ Заказ")],
        [KeyboardButton("🔍 Статус"), KeyboardButton("📍 Контакты")],
    ]
    return ReplyKeyboardMarkup(buttons, resize_keyboard=True)


def get_cancel_button() -> ReplyKeyboardMarkup:
    """Кнопка отмены."""
    buttons = [[KeyboardButton("/cancel")]]
    return ReplyKeyboardMarkup(buttons, resize_keyboard=True)


def get_skip_photo_keyboard() -> InlineKeyboardMarkup:
    """Кнопка пропуска фото."""
    buttons = [
        [InlineKeyboardButton("⏭️ Пропустить фото", callback_data="skip_photo")],
    ]
    return InlineKeyboardMarkup(buttons)


def get_faq_keyboard() -> InlineKeyboardMarkup:
    """Меню FAQ."""
    buttons = [
        [InlineKeyboardButton("❓ Часто задаваемые вопросы", callback_data="show_faq")],
        [InlineKeyboardButton("💰 Цены на услуги", callback_data="show_prices")],
        [InlineKeyboardButton("📞 Контакты и адрес", callback_data="show_contacts")],
        [InlineKeyboardButton("🕐 Режим работы", callback_data="show_hours")],
    ]
    return InlineKeyboardMarkup(buttons)


def get_menu_button_keyboard() -> ReplyKeyboardMarkup:
    """Меню с основными командами (Reply клавиатура)."""
    buttons = [
        [KeyboardButton("/start"), KeyboardButton("/order")],
        [KeyboardButton("/services"), KeyboardButton("/contact")],
        [KeyboardButton("/help")],
    ]
    return ReplyKeyboardMarkup(buttons, resize_keyboard=True, one_time_keyboard=False)
