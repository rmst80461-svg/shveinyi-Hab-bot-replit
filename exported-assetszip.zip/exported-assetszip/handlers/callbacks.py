"""
Обработчики нажатий на inline кнопки (callback_query).
"""

import logging
import json
from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ParseMode

from handlers.keyboards import get_services_keyboard, get_main_menu, get_cancel_button
from utils import config

logger = logging.getLogger(__name__)

# Загрузка данных
try:
    with open('data/workshop_info.json', 'r', encoding='utf-8') as f:
        WORKSHOP_INFO = json.load(f)
except Exception as e:
    logger.error(f"Ошибка загрузки workshop_info.json: {e}")
    WORKSHOP_INFO = {}

try:
    with open('data/services_data.json', 'r', encoding='utf-8') as f:
        SERVICES_DATA = json.load(f)
except Exception as e:
    logger.error(f"Ошибка загрузки services_data.json: {e}")
    SERVICES_DATA = {}

try:
    with open('data/faq.json', 'r', encoding='utf-8') as f:
        FAQ_DATA = json.load(f)
except Exception as e:
    logger.error(f"Ошибка загрузки faq.json: {e}")
    FAQ_DATA = {}

try:
    with open('data/prices.json', 'r', encoding='utf-8') as f:
        PRICES_DATA = json.load(f)
except Exception as e:
    logger.error(f"Ошибка загрузки prices.json: {e}")
    PRICES_DATA = {}


async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Обработчик всех callback запросов от кнопок."""
    query = update.callback_query
    await query.answer()  # Закрыть loading индикатор

    callback_data = query.data

    if callback_data == "services":
        await query.edit_message_text(
            text="<b>📋 Выберите услугу:</b>",
            reply_markup=get_services_keyboard(),
            parse_mode=ParseMode.HTML
        )

    elif callback_data == "order":
        await query.edit_message_text(
            text="<b>➕ Оформление заказа</b>\n\n"
                 "Для оформления нового заказа используйте команду /order\n\n"
                 "Процесс заказа:\n"
                 "1️⃣ Выбираете услугу\n"
                 "2️⃣ Загружаете фото (опционально)\n"
                 "3️⃣ Указываете имя и телефон\n"
                 "4️⃣ Заказ принят! ✅\n\n"
                 "<i>Тапните /order чтобы начать</i>",
            parse_mode=ParseMode.HTML
        )

    elif callback_data == "status":
        info = WORKSHOP_INFO
        await query.edit_message_text(
            text="<b>🔍 Проверка статуса</b>\n\n"
                 "Пожалуйста, введите номер вашего заказа или свяжитесь с нами:\n"
                 f"📞 {info.get('phone_main', '+7 (968) 396-91-52')}"
        )

    elif callback_data.startswith("service_"):
        service_type = callback_data.replace("service_", "")
        services_map = {
            "hem": ("👖 Подшить брюки/юбку", "Подгиб изделия, подшивка"),
            "zipper": ("🔌 Заменить молнию", "Замена застежки-молнии"),
            "alter": ("📏 Ушить/расширить", "Изменение размера"),
            "buttons": ("🔘 Пришить пуговицы", "Пришивание фурнитуры"),
            "patch": ("🩹 Заплатка/заштопать", "Ремонт дырок и порывов"),
            "custom": ("👗 Индивидуальный пошив", "Пошив по индивидуальным размерам"),
        }

        if service_type in services_map:
            title, desc = services_map[service_type]
            await query.edit_message_text(
                text=f"<b>{title}</b>\n\n{desc}\n\n"
                     f"Для оформления заказа используйте команду /order",
                parse_mode=ParseMode.HTML
            )

    elif callback_data == "confirm_order":
        await query.edit_message_text(text="✅ Спасибо! Ваш заказ принят.")

    elif callback_data == "cancel_order":
        await query.edit_message_text(
            text="❌ Заказ отменен.",
            reply_markup=get_main_menu()
        )

    elif callback_data == "skip_photo":
        await query.delete_message()
        await query.message.reply_text(
            "Как к вам обращаться? Укажите имя:",
            reply_markup=get_cancel_button(),
            parse_mode=ParseMode.HTML
        )

    elif callback_data == "show_faq":
        faq_list = FAQ_DATA.get('faq', [])
        text = "<b>❓ Часто задаваемые вопросы</b>\n\n"
        
        # Показываем первые 10 вопросов с кнопками
        buttons = []
        for item in faq_list[:10]:
            faq_id = item.get('id', '')
            question = item.get('question', '')
            buttons.append([InlineKeyboardButton(question, callback_data=f"faq_q_{faq_id}")])
        
        # Добавляем кнопки навигации
        nav_buttons = []
        if len(faq_list) > 10:
            nav_buttons.append(InlineKeyboardButton("📄 Еще вопросы", callback_data="faq_more"))
        nav_buttons.append(InlineKeyboardButton("❓ Свой вопрос", callback_data="faq_custom"))
        
        if nav_buttons:
            buttons.append(nav_buttons)
        
        keyboard = InlineKeyboardMarkup(buttons)
        text = f"<b>❓ Часто задаваемые вопросы ({len(faq_list)} всего)</b>\n\n" \
               "<i>Нажмите на вопрос чтобы увидеть ответ 👇</i>"
        await query.edit_message_text(text=text, reply_markup=keyboard, parse_mode=ParseMode.HTML)
    
    elif callback_data.startswith("faq_q_"):
        # Показываем ответ на конкретный вопрос
        faq_id = callback_data.replace("faq_q_", "")
        faq_list = FAQ_DATA.get('faq', [])
        
        # Ищем вопрос по ID
        current_item = None
        current_index = 0
        for idx, item in enumerate(faq_list):
            if item.get('id') == faq_id:
                current_item = item
                current_index = idx
                break
        
        if current_item:
            text = f"<b>❓ {current_item.get('question', '')}</b>\n\n" \
                   f"<i>{current_item.get('answer', '')}</i>\n\n" \
                   f"<b>Вопрос {current_index + 1} из {len(faq_list)}</b>"
            
            # Кнопки навигации
            nav_buttons = []
            if current_index > 0:
                prev_id = faq_list[current_index - 1].get('id')
                nav_buttons.append(InlineKeyboardButton("⬅️ Предыдущий", callback_data=f"faq_q_{prev_id}"))
            
            if current_index < len(faq_list) - 1:
                next_id = faq_list[current_index + 1].get('id')
                nav_buttons.append(InlineKeyboardButton("Следующий ➡️", callback_data=f"faq_q_{next_id}"))
            
            nav_buttons.append(InlineKeyboardButton("📋 Все вопросы", callback_data="show_faq"))
            
            keyboard = InlineKeyboardMarkup([nav_buttons] if nav_buttons else [[InlineKeyboardButton("📋 Все вопросы", callback_data="show_faq")]])
            await query.edit_message_text(text=text, reply_markup=keyboard, parse_mode=ParseMode.HTML)
    
    elif callback_data == "faq_more":
        # Показываем остальные вопросы
        faq_list = FAQ_DATA.get('faq', [])[10:]
        text = "<b>❓ Еще вопросы</b>\n\n"
        
        buttons = []
        for item in faq_list:
            faq_id = item.get('id', '')
            question = item.get('question', '')
            buttons.append([InlineKeyboardButton(question, callback_data=f"faq_q_{faq_id}")])
        
        buttons.append([InlineKeyboardButton("📋 Назад", callback_data="show_faq")])
        
        keyboard = InlineKeyboardMarkup(buttons)
        text = f"<b>❓ Остальные вопросы ({len(faq_list)})</b>\n\n" \
               "<i>Нажмите на вопрос чтобы увидеть ответ 👇</i>"
        await query.edit_message_text(text=text, reply_markup=keyboard, parse_mode=ParseMode.HTML)
    
    elif callback_data == "faq_custom":
        # Пользователь хочет задать свой вопрос
        await query.edit_message_text(
            text="<b>❓ Задайте свой вопрос</b>\n\n"
                 "Напишите ваш вопрос в чат, и я найду ответ в нашей базе знаний или попрошу помощь у AI! 💬",
            parse_mode=ParseMode.HTML
        )

    elif callback_data == "show_prices":
        categories = PRICES_DATA.get('categories', {})
        text = "<b>💰 Прайс-лист услуг:</b>\n\n"
        
        for key, category in list(categories.items())[:5]:
            text += f"{category.get('emoji', '🔧')} <b>{category.get('name', 'Категория')}</b>\n"
            services = category.get('services', [])
            for service in services[:2]:
                text += f"  • {service.get('name', '')}\n"
                text += f"    💵 {service.get('price', '')}\n"
            text += "\n"
        
        text += "<i>Полный прайс и детали — напишите в чат!</i>\n"
        text += f"<b>Срочный ремонт:</b> +50% к стоимости"
        await query.edit_message_text(text=text, parse_mode=ParseMode.HTML)

    elif callback_data == "show_contacts":
        info = WORKSHOP_INFO
        text = f"<b>📞 Контакты мастерской:</b>\n\n"
        text += f"📍 <b>Адрес:</b>\n{info.get('address', 'г. Москва, ул. Маршала Федоренко, д. 12')}\n\n"
        text += f"📞 <b>Телефон:</b>\n{info.get('phone_main', '+7 (968) 396-91-52')}\n\n"
        text += f"💬 <b>WhatsApp:</b>\n{info.get('phone_whatsapp', '+7 (968) 396-91-52')}"
        await query.edit_message_text(text=text, parse_mode=ParseMode.HTML)

    elif callback_data == "show_hours":
        info = WORKSHOP_INFO
        hours = info.get('working_hours', {})
        text = (
            f"<b>🕐 Режим работы:</b>\n\n"
            f"📅 <b>Пн-Чт:</b> {hours.get('monday_thursday', '10:00 - 19:50')}\n"
            f"📅 <b>Пт:</b> {hours.get('friday', '10:00 - 19:00')}\n"
            f"📅 <b>Сб:</b> {hours.get('saturday', '10:00 - 17:00')}\n"
            f"📅 <b>Вс:</b> {hours.get('sunday', 'Выходной')}\n\n"
            f"⚠️ <b>Внимание:</b> Запись не требуется!\n"
            f"Можете прийти в любое время работы.\n\n"
            f"📞 <b>Позвонить:</b> {info.get('phone_main', '+7 (968) 396-91-52')}"
        )
        await query.edit_message_text(text=text, parse_mode=ParseMode.HTML)

    logger.info(f"Callback обработан: {callback_data}")
