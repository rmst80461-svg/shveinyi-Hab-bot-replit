"""
Обработчики администраторских команд.
"""

import logging
from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ParseMode
from utils import config

logger = logging.getLogger(__name__)


def require_admin(func):
    """Декоратор для проверки прав администратора."""
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if update.effective_user.id not in config.ADMIN_IDS:
            await update.message.reply_text("❌ У вас нет доступа к этой команде.")
            return
        return await func(update, context)
    return wrapper


@require_admin
async def admin_stats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Показать статистику бота."""
    stats = context.application.bot_data.get("db").get_statistics()

    stats_text = f"""<b>📊 СТАТИСТИКА БОТА</b>

<b>Пользователи:</b>
  • Всего: {stats.get('total_users', 0)}
  • За последний день: {stats.get('users_today', 0)}

<b>Заказы:</b>
  • Всего: {stats.get('total_orders', 0)}
  • Новых: {stats.get('orders_new', 0)}
  • В работе: {stats.get('orders_in_progress', 0)}
  • Готовых: {stats.get('orders_ready', 0)}

<b>Спам:</b>
  • Заблокировано: {stats.get('blocked_users', 0)}
  • Предупреждений: {stats.get('total_warnings', 0)}"""

    await update.message.reply_text(stats_text, parse_mode=ParseMode.HTML)


@require_admin
async def admin_orders(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Показать список заказов."""
    orders = context.application.bot_data.get("db").get_recent_orders(limit=10)

    if not orders:
        await update.message.reply_text("Нет заказов.")
        return

    orders_text = "<b>📋 ПОСЛЕДНИЕ ЗАКАЗЫ</b>\n\n"

    for order in orders:
        orders_text += (
            f"<b>ID:</b> {order['order_id']}\n"
            f"<b>Услуга:</b> {order['service_type']}\n"
            f"<b>Статус:</b> {order['status']}\n"
            f"<b>Цена:</b> {order['estimated_price']}₽\n"
            f"<b>Дата:</b> {order['created_at']}\n\n"
        )

    await update.message.reply_text(orders_text, parse_mode=ParseMode.HTML)


@require_admin
async def admin_spam_log(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Показать лог спама."""
    spam_entries = context.application.bot_data.get("db").get_spam_log(limit=20)

    if not spam_entries:
        await update.message.reply_text("Нет записей спама.")
        return

    spam_text = "<b>🚫 ЛОГ СПАМА</b>\n\n"

    for entry in spam_entries:
        spam_text += (
            f"<b>Тип:</b> {entry['spam_type']}\n"
            f"<b>Дата:</b> {entry['timestamp']}\n\n"
        )

    await update.message.reply_text(spam_text, parse_mode=ParseMode.HTML)
