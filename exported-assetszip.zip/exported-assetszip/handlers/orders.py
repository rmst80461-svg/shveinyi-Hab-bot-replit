"""
Обработчик flow оформления заказов (conversation handler).
"""

import logging
import uuid
from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes, ConversationHandler
from telegram.constants import ParseMode

from handlers.keyboards import get_services_keyboard, get_cancel_button, get_skip_photo_keyboard
from utils import config

logger = logging.getLogger(__name__)

# Константы состояний conversation
SELECT_SERVICE = 1
SERVICE_PHOTO = 2
USER_NAME = 3
USER_PHONE = 4


async def order_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Начало оформления заказа."""
    await update.message.reply_text(
        "<b>➕ Оформление нового заказа</b>\n\n"
        "Выберите нужную услугу:",
        reply_markup=get_services_keyboard(),
        parse_mode=ParseMode.HTML
    )
    return SELECT_SERVICE


async def select_service(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Выбор услуги."""
    service_map = {
        "hem": "Подшить брюки/юбку",
        "zipper": "Заменить молнию",
        "alter": "Ушить/расширить",
        "buttons": "Пришить пуговицы",
        "patch": "Заплатка/заштопать",
        "custom": "Индивидуальный пошив",
    }

    # Сохранение выбора
    context.user_data['service'] = update.message.text

    await update.message.reply_text(
        "Отлично! ✂️\n\n"
        f"<b>Услуга:</b> {context.user_data['service']}\n\n"
        "Пожалуйста, пришлите фото изделия 📸\n"
        "<i>(фото опционально, можете пропустить)</i>",
        parse_mode=ParseMode.HTML,
        reply_markup=get_skip_photo_keyboard()
    )
    return SERVICE_PHOTO


async def receive_photo(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Получение фото изделия."""
    if update.message.photo:
        photo = update.message.photo[-1]  # Берем максимальное разрешение
        context.user_data['photo_id'] = photo.file_id
        message_text = "Спасибо за фото! 😊\n\n"
    else:
        context.user_data['photo_id'] = None
        message_text = "Понял, фото не нужно! ✅\n\n"

    await update.message.reply_text(
        f"{message_text}"
        "Как к вам обращаться? Укажите имя:",
        reply_markup=get_cancel_button()
    )
    return USER_NAME


async def receive_name(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Получение имени пользователя."""
    context.user_data['name'] = update.message.text

    await update.message.reply_text(
        f"Спасибо, {context.user_data['name']}! ✅\n\n"
        "И ваш номер телефона для связи? 📱\n"
        "<i>Например: +7 (968) 396-91-52 или другой ваш номер</i>",
        parse_mode=ParseMode.HTML,
        reply_markup=get_cancel_button()
    )
    return USER_PHONE


async def receive_phone(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Получение телефона и завершение заказа."""
    phone = update.message.text
    context.user_data['phone'] = phone

    # Генерируем ID заказа
    order_id = str(uuid.uuid4())[:8].upper()

    # Сохраняем заказ в БД
    photo_id = context.user_data.get('photo_id')
    description = f"Фото: {photo_id}" if photo_id else "Фото не загружено"
    
    context.application.bot_data.get("db").create_order(
        user_id=update.effective_user.id,
        service_type=context.user_data['service'],
        description=description,
        photo_file_id=photo_id,
        estimated_price=500,  # Примерная цена
    )

    # Уведомление пользователю
    confirmation = (
        f"✅ <b>Заказ принят!</b>\n\n"
        f"<b>№ заказа:</b> {order_id}\n"
        f"<b>Услуга:</b> {context.user_data['service']}\n"
        f"<b>Ваше имя:</b> {context.user_data['name']}\n"
        f"<b>Телефон:</b> {phone}\n"
        f"<b>Примерная стоимость:</b> 500₽\n\n"
        f"Спасибо за обращение! Мы свяжемся с вами в ближайшее время. 💬"
    )

    await update.message.reply_text(
        confirmation,
        parse_mode=ParseMode.HTML
    )

    # Уведомление администратору
    admin_notification = (
        f"<b>🔔 Новый заказ!</b>\n\n"
        f"<b>ID заказа:</b> {order_id}\n"
        f"<b>Пользователь:</b> {update.effective_user.first_name} (@{update.effective_user.username})\n"
        f"<b>Услуга:</b> {context.user_data['service']}\n"
        f"<b>Имя:</b> {context.user_data['name']}\n"
        f"<b>Телефон:</b> {phone}\n"
        f"<b>Время:</b> {update.message.date}"
    )

    for admin_id in config.ADMIN_IDS:
        try:
            await context.bot.send_message(
                chat_id=admin_id,
                text=admin_notification,
                parse_mode=ParseMode.HTML
            )
        except Exception as e:
            logger.error(f"Ошибка отправки админ-уведомления: {e}")

    return ConversationHandler.END


async def check_status(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Проверка статуса заказа."""
    await update.message.reply_text(
        "Введите номер вашего заказа (8 символов):"
    )


async def skip_photo_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Пропуск загрузки фото."""
    query = update.callback_query
    await query.answer()
    await query.delete_message()
    
    # Отмечаем, что фото не загружено
    context.user_data['photo_id'] = None
    
    await query.message.reply_text(
        "Понял, фото не нужно! ✅\n\n"
        "Как к вам обращаться? Укажите имя:",
        reply_markup=get_cancel_button()
    )
    return USER_NAME


async def cancel_order(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Отмена заказа."""
    await update.message.reply_text(
        "❌ Заказ отменен.\n\n"
        "Если передумали - просто выполните /order заново! 😊"
    )
    return ConversationHandler.END
