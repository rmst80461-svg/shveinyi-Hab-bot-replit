"""
Обработчик обычных текстовых сообщений.
Включает поиск в базе знаний, FAQ и интеграцию с GigaChat.
"""

import logging
import json
from difflib import SequenceMatcher
from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ParseMode

from utils.knowledge_base import KnowledgeBase
from utils.gigachat_api import ask_gigachat
from utils.anti_spam import check_spam, is_workshop_related
from utils import config

logger = logging.getLogger(__name__)

kb = KnowledgeBase()

# Загрузка FAQ
try:
    with open('data/faq.json', 'r', encoding='utf-8') as f:
        FAQ_DATA = json.load(f)
except Exception as e:
    logger.error(f"Ошибка загрузки FAQ: {e}")
    FAQ_DATA = {}


def find_faq_answer(question: str) -> str:
    """Ищет похожий вопрос в FAQ."""
    if not FAQ_DATA.get('faq'):
        return ""
    
    best_match = None
    best_ratio = 0.4  # Порог схожести
    
    for faq_item in FAQ_DATA['faq']:
        ratio = SequenceMatcher(None, question.lower(), 
                               faq_item.get('question', '').lower()).ratio()
        if ratio > best_ratio:
            best_ratio = ratio
            best_match = faq_item.get('answer', '')
    
    return best_match if best_match else ""


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Основной обработчик текстовых сообщений.
    Следует логике: спам-проверка → KB → GigaChat.
    """
    user = update.effective_user
    message_text = update.message.text

    logger.info(f"Сообщение от {user.id}: {message_text[:50]}")

    # === ПРОВЕРКА СПАМА ===
    spam_check = await check_spam(user.id, message_text)

    if spam_check['is_blocked']:
        await update.message.reply_text(config.BLOCK_MESSAGE)
        return

    if spam_check['is_spam']:
        await update.message.reply_text(config.WARNING_MESSAGE)
        if spam_check['warning_added']:
            await update.message.reply_text(
                f"⚠️ Предупреждение ({spam_check['warnings']}/{config.WARNING_LIMIT})"
            )
        return

    if spam_check['rate_limited']:
        await update.message.reply_text(config.RATE_LIMIT_MESSAGE)
        return

    # === ПОИСК В БАЗЕ ЗНАНИЙ ===
    kb_answer = kb.search(message_text)

    if kb_answer:
        logger.info(f"Найден ответ в KB для пользователя {user.id}")
        await update.message.reply_text(
            f"✂️ {kb_answer}\n\n<i>Если вам нужна дополнительная информация, пишите!</i>",
            parse_mode=ParseMode.HTML
        )
        return

    # === ПОИСК В FAQ ===
    faq_answer = find_faq_answer(message_text)
    if faq_answer:
        logger.info(f"Найден ответ в FAQ для пользователя {user.id}")
        await update.message.reply_text(
            f"📌 {faq_answer}\n\n<i>Нужна ещё помощь? Обращайтесь!</i>",
            parse_mode=ParseMode.HTML
        )
        return

    # === ПРОВЕРКА РЕЛЕВАНТНОСТИ ===
    if not await is_workshop_related(message_text):
        await update.message.reply_text(config.WARNING_MESSAGE)
        return

    # === ОТПРАВКА В GIGACHAT ===
    await update.message.chat.send_action("typing")

    try:
        response = await ask_gigachat(message_text)
        await update.message.reply_text(
            f"💬 {response}\n\n<i>Если нужна дополнительная информация, обращайтесь!</i>",
            parse_mode=ParseMode.HTML
        )
    except Exception as e:
        logger.error(f"Ошибка GigaChat: {e}")
        await update.message.reply_text(
            "Извините, произошла ошибка при обработке вашего вопроса. "
            "Пожалуйста, попробуйте позже или свяжитесь с администратором. 📞"
        )
