"""
Обработчики команд (/start, /help, /services, /contact).
"""

import logging
from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ParseMode

from handlers.keyboards import get_main_menu, get_services_keyboard
from utils import config

logger = logging.getLogger(__name__)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Обработчик команды /start.
    Приветствует пользователя и показывает главное меню.
    """
    user = update.effective_user
    logger.info(f"Новый пользователь: {user.id} (@{user.username})")

    # Добавление пользователя в базу данных
    db = context.application.bot_data.get("db")
    if db:
        await db.add_user(
            user_id=user.id,
            username=user.username or "Unknown",
            first_name=user.first_name or "User"
        )

    # Приветственное сообщение
    await update.message.reply_text(
        config.WELCOME_MESSAGE,
        reply_markup=get_main_menu(),
        parse_mode=ParseMode.HTML
    )


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Обработчик команды /help."""
    help_text = """<b>📖 Справка по боту</b>

<b>Основные команды:</b>
/start - Главное меню
/services - Каталог услуг
/order - Оформить заказ
/status - Проверить статус заказа
/contact - Контакты мастерской
/help - Эта справка

<b>Как использовать:</b>
1️⃣ Выберите интересующую вас команду
2️⃣ Ответьте на вопросы бота
3️⃣ Загрузите фото изделия
4️⃣ Получите уведомление о готовности

<b>Вопросы:</b>
Просто напишите мне любой вопрос о ремонте одежды, и я помогу! 💬"""

    await update.message.reply_text(
        help_text,
        parse_mode=ParseMode.HTML
    )


async def services(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Обработчик команды /services."""
    services_text = """<b>🧵 УСЛУГИ МАСТЕРСКОЙ</b>

<b>👖 Подшить брюки/юбку</b>
  • Простая подгибка: 300₽
  • Со сбережением фабричного шва: 500₽

<b>🔌 Заменить молнию</b>
  • Простая замена: 400₽
  • Метал/дизайнерская молния: 800₽

<b>📏 Ушить/расширить одежду</b>
  • Ушить по боку: 500-700₽
  • Расширить: 600-1000₽

<b>🔘 Пришить пуговицы</b>
  • Одна пуговица: 100₽
  • Несколько: 200₽

<b>🩹 Заплатка/зашить дыру</b>
  • Скрытый шов: 300₽
  • Видимая заплатка: 400₽
  • Большая дыра: 600₽

<b>👗 Индивидуальный пошив</b>
  • Расценки по договоренности

<i>Все цены указаны примерно и могут измениться в зависимости от сложности работы.</i>"""

    await update.message.reply_text(
        services_text,
        parse_mode=ParseMode.HTML
    )


async def contact(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Обработчик команды /contact."""
    # Данные загружаются из JSON, используем кнопки для отображения
    await update.message.reply_text(
        "<b>📍 КОНТАКТЫ МАСТЕРСКОЙ</b>\n\n"
        "Нажмите на кнопку ниже для получения контактной информации:",
        reply_markup=get_main_menu(),
        parse_mode=ParseMode.HTML
    )
